import type { Metadata } from "next";
import { Geist, Geist_Mono } from "next/font/google";
import "./globals.css";
import { Toaster } from "@/components/ui/toaster";

const geistSans = Geist({
  variable: "--font-geist-sans",
  subsets: ["latin"],
});

const geistMono = Geist_Mono({
  variable: "--font-geist-mono",
  subsets: ["latin"],
});

export const metadata: Metadata = {
  title: "Sistem Data Kependudukan RT.001/RW.002 Sukamaju",
  description: "Sistem Informasi Administrasi Kependudukan RT.001/RW.002 Sukamaju, Cibungbulang, Bogor, Jawa Barat. Ketua RT: Herman Gozali.",
  keywords: ["SIAK", "Kependudukan", "RT", "Sukamaju", "Cibungbulang", "Bogor"],
  authors: [{ name: "RT.001/RW.002 Sukamaju" }],
  icons: {
    icon: "https://z-cdn.chatglm.cn/z-ai/static/logo.svg",
  },
};

export default function RootLayout({
  children,
}: Readonly<{
  children: React.ReactNode;
}>) {
  return (
    <html lang="en" suppressHydrationWarning>
      <body
        className={`${geistSans.variable} ${geistMono.variable} antialiased bg-background text-foreground`}
      >
        {children}
        <Toaster />
      </body>
    </html>
  );
}
