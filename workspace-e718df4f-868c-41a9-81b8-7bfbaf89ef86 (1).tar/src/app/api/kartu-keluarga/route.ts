import { NextRequest, NextResponse } from 'next/server';
import { db } from '@/lib/db';

export async function GET() {
  try {
    const kartuKeluarga = await db.kartuKeluarga.findMany({
      include: {
        penduduk: {
          where: { aktif: true },
          select: {
            id: true,
            nik: true,
            nama: true,
            jenisKelamin: true,
            isKepalaKeluarga: true,
          }
        }
      },
      orderBy: { createdAt: 'desc' }
    });

    const result = kartuKeluarga.map(kk => ({
      ...kk,
      jumlahAnggota: kk.penduduk.length,
      kepalaKeluarga: kk.penduduk.find(p => p.isKepalaKeluarga)
    }));

    return NextResponse.json(result);
  } catch (error) {
    console.error('Error fetching kartu keluarga:', error);
    return NextResponse.json({ error: 'Gagal mengambil data kartu keluarga' }, { status: 500 });
  }
}

export async function POST(request: NextRequest) {
  try {
    const data = await request.json();
    const { noKK, namaKepalaKeluarga, alamat, bantuan, nomorHP, namaAlias, anggota } = data;

    // Validasi No KK harus 16 digit
    if (!/^[0-9]{16}$/.test(noKK)) {
      return NextResponse.json({ error: 'No KK harus 16 digit angka' }, { status: 400 });
    }

    const existingKK = await db.kartuKeluarga.findUnique({
      where: { noKK }
    });

    if (existingKK) {
      return NextResponse.json({ error: 'No KK sudah terdaftar' }, { status: 400 });
    }

    const kartuKeluarga = await db.kartuKeluarga.create({
      data: {
        noKK,
        namaKepalaKeluarga,
        alamat: alamat || '',
        bantuan: JSON.stringify(bantuan || []),
        nomorHP: nomorHP || '',
        namaAlias: namaAlias || '',
      }
    });

    if (anggota && anggota.length > 0) {
      // Validasi dan cek duplikat NIK
      for (const member of anggota) {
        // Validasi NIK harus 16 digit
        if (!/^[0-9]{16}$/.test(member.nik)) {
          return NextResponse.json({ error: `NIK ${member.nama || member.nik} harus 16 digit angka` }, { status: 400 });
        }
        
        const existingPenduduk = await db.penduduk.findUnique({
          where: { nik: member.nik }
        });
        if (existingPenduduk) {
          return NextResponse.json({ error: `NIK ${member.nik} sudah terdaftar` }, { status: 400 });
        }
      }
      
      for (const member of anggota) {
        await db.penduduk.create({
          data: {
            nik: member.nik,
            nama: member.nama,
            jenisKelamin: member.jenisKelamin,
            tempatLahir: member.tempatLahir || '',
            tanggalLahir: member.tanggalLahir ? new Date(member.tanggalLahir) : null,
            agama: member.agama || 'ISLAM',
            pendidikan: member.pendidikan || '',
            pekerjaan: member.pekerjaan || '',
            statusPerkawinan: member.statusPerkawinan || 'BELUM MENIKAH',
            kewarganegaraan: member.kewarganegaraan || 'WNI',
            statusWarga: member.statusWarga || 'TETAP',
            namaAyah: member.namaAyah || '',
            namaIbu: member.namaIbu || '',
            namaPanggilan: member.namaPanggilan || '',
            bpjs: member.bpjs || 'Tidak',
            noKKId: kartuKeluarga.id,
            isKepalaKeluarga: member.isKepalaKeluarga || false,
          }
        });
      }
    }

    return NextResponse.json(kartuKeluarga);
  } catch (error) {
    console.error('Error creating kartu keluarga:', error);
    return NextResponse.json({ error: 'Gagal membuat kartu keluarga' }, { status: 500 });
  }
}
