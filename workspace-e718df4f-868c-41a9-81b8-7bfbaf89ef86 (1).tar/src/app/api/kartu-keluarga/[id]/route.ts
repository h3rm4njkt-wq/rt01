import { NextRequest, NextResponse } from 'next/server';
import { db } from '@/lib/db';

export async function GET(
  request: NextRequest,
  { params }: { params: Promise<{ id: string }> }
) {
  try {
    const { id } = await params;
    const kartuKeluarga = await db.kartuKeluarga.findUnique({
      where: { id },
      include: {
        penduduk: {
          where: { aktif: true },
          orderBy: [
            { isKepalaKeluarga: 'desc' },
            { tanggalLahir: 'asc' }
          ]
        }
      }
    });

    if (!kartuKeluarga) {
      return NextResponse.json({ error: 'Kartu keluarga tidak ditemukan' }, { status: 404 });
    }

    return NextResponse.json(kartuKeluarga);
  } catch (error) {
    console.error('Error fetching kartu keluarga:', error);
    return NextResponse.json({ error: 'Gagal mengambil data kartu keluarga' }, { status: 500 });
  }
}

export async function PUT(
  request: NextRequest,
  { params }: { params: Promise<{ id: string }> }
) {
  try {
    const { id } = await params;
    const data = await request.json();
    
    // Validasi No KK harus 16 digit
    if (data.noKK && !/^[0-9]{16}$/.test(data.noKK)) {
      return NextResponse.json({ error: 'No KK harus 16 digit angka' }, { status: 400 });
    }
    
    // Cek duplikat No KK (exclude current record)
    if (data.noKK) {
      const existingKK = await db.kartuKeluarga.findFirst({
        where: { 
          noKK: data.noKK,
          NOT: { id }
        }
      });
      if (existingKK) {
        return NextResponse.json({ error: 'No KK sudah terdaftar' }, { status: 400 });
      }
    }

    const kartuKeluarga = await db.kartuKeluarga.update({
      where: { id },
      data: {
        noKK: data.noKK,
        namaKepalaKeluarga: data.namaKepalaKeluarga,
        alamat: data.alamat || '',
        nomorHP: data.nomorHP || '',
        namaAlias: data.namaAlias || '',
        bantuan: JSON.stringify(data.bantuan || []),
      }
    });

    return NextResponse.json(kartuKeluarga);
  } catch (error) {
    console.error('Error updating kartu keluarga:', error);
    return NextResponse.json({ error: 'Gagal mengupdate kartu keluarga' }, { status: 500 });
  }
}

export async function DELETE(
  request: NextRequest,
  { params }: { params: Promise<{ id: string }> }
) {
  try {
    const { id } = await params;
    
    await db.penduduk.deleteMany({
      where: { noKKId: id }
    });
    
    await db.kartuKeluarga.delete({
      where: { id }
    });

    return NextResponse.json({ success: true });
  } catch (error) {
    console.error('Error deleting kartu keluarga:', error);
    return NextResponse.json({ error: 'Gagal menghapus kartu keluarga' }, { status: 500 });
  }
}
