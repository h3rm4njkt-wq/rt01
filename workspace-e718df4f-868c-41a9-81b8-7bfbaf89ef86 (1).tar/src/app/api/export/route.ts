import { NextRequest, NextResponse } from 'next/server';
import { db } from '@/lib/db';

function formatDate(date: Date | null): string {
  if (!date) return '';
  const d = new Date(date);
  const day = d.getDate().toString().padStart(2, '0');
  const month = (d.getMonth() + 1).toString().padStart(2, '0');
  const year = d.getFullYear();
  return `${day}/${month}/${year}`;
}

function calculateAge(birthDate: Date | null): number {
  if (!birthDate) return 0;
  const today = new Date();
  let age = today.getFullYear() - birthDate.getFullYear();
  const monthDiff = today.getMonth() - birthDate.getMonth();
  if (monthDiff < 0 || (monthDiff === 0 && today.getDate() < birthDate.getDate())) {
    age--;
  }
  return age;
}

export async function GET(request: NextRequest) {
  try {
    const { searchParams } = new URL(request.url);
    const type = searchParams.get('type') || 'all';
    
    const XLSX = await import('xlsx');
    const workbook = XLSX.utils.book_new();
    
    if (type === 'all' || type === 'penduduk') {
      const penduduk = await db.penduduk.findMany({
        where: { aktif: true },
        include: { kartuKeluarga: true },
        orderBy: [
          { isKepalaKeluarga: 'desc' },
          { nama: 'asc' }
        ]
      });

      const pendudukData = penduduk.map(p => ({
        'NO. KK': p.kartuKeluarga?.noKK || '',
        'Nama Lengkap': p.nama,
        'NIK': p.nik,
        'Jenis Kelamin': p.jenisKelamin,
        'Tempat Lahir': p.tempatLahir || '',
        'Tanggal Lahir': formatDate(p.tanggalLahir),
        'Agama': p.agama || '',
        'Pendidikan': p.pendidikan || '',
        'Jenis Pekerjaan': p.pekerjaan || '',
        'Status Perkawinan': p.statusPerkawinan || '',
        'Kewarganegaraan': p.kewarganegaraan || '',
        'Status Warga': p.statusWarga || '',
        'Nama Ayah': p.namaAyah || '',
        'Nama Ibu': p.namaIbu || '',
        'Nama Panggilan': p.namaPanggilan || '',
        'USIA L': p.jenisKelamin === 'Laki-Laki' ? calculateAge(p.tanggalLahir) : '',
        'USIA P': p.jenisKelamin === 'Perempuan' ? calculateAge(p.tanggalLahir) : '',
      }));

      const ws = XLSX.utils.json_to_sheet(pendudukData);
      XLSX.utils.book_append_sheet(workbook, ws, 'Data Penduduk');
    }

    if (type === 'all' || type === 'kartu-keluarga') {
      const kk = await db.kartuKeluarga.findMany({
        include: {
          penduduk: {
            where: { aktif: true }
          }
        },
        orderBy: { namaKepalaKeluarga: 'asc' }
      });

      const kkData = kk.map(k => ({
        'NO. KK': k.noKK,
        'Nama Kepala Keluarga': k.namaKepalaKeluarga,
        'Alamat': k.alamat || '',
        'No. HP': k.nomorHP || '',
        'Nama Alias': k.namaAlias || '',
        'Jumlah Anggota': k.penduduk.length,
        'Bantuan': JSON.parse(k.bantuan || '[]').join(', '),
      }));

      const ws = XLSX.utils.json_to_sheet(kkData);
      XLSX.utils.book_append_sheet(workbook, ws, 'Kartu Keluarga');
    }

    if (type === 'laporan') {
      const penduduk = await db.penduduk.findMany({
        where: { aktif: true },
        include: { kartuKeluarga: true }
      });

      const kartuKeluarga = await db.kartuKeluarga.findMany({
        include: {
          penduduk: {
            where: { aktif: true, isKepalaKeluarga: true }
          }
        }
      });

      const kejadian = await db.kejadian.findMany({
        include: { penduduk: true }
      });

      function calculateAgeInMonths(birthDate: Date | null): number {
        if (!birthDate) return 0;
        const today = new Date();
        return (today.getFullYear() - birthDate.getFullYear()) * 12 + (today.getMonth() - birthDate.getMonth());
      }

      function isNew17YearsOld(birthDate: Date | null): boolean {
        if (!birthDate) return false;
        const today = new Date();
        const age = calculateAge(birthDate);
        if (age !== 17) return false;
        const thisYearBirthday = new Date(today.getFullYear(), birthDate.getMonth(), birthDate.getDate());
        const daysSinceBirthday = Math.floor((today.getTime() - thisYearBirthday.getTime()) / (1000 * 60 * 60 * 24));
        return daysSinceBirthday >= 0 && daysSinceBirthday <= 30;
      }

      const laporanData: Record<string, unknown>[] = [];
      
      laporanData.push({ 'KATEGORI': 'PENDUDUK', 'LAKI-LAKI': penduduk.filter(p => p.jenisKelamin === 'Laki-Laki').length, 'PEREMPUAN': penduduk.filter(p => p.jenisKelamin === 'Perempuan').length, 'JUMLAH': penduduk.length });
      laporanData.push({ 'KATEGORI': 'KARTU KELUARGA', 'LAKI-LAKI': kartuKeluarga.filter(kk => kk.penduduk.some(p => p.jenisKelamin === 'Laki-Laki')).length, 'PEREMPUAN': kartuKeluarga.filter(kk => kk.penduduk.some(p => p.jenisKelamin === 'Perempuan')).length, 'JUMLAH': kartuKeluarga.length });
      laporanData.push({ 'KATEGORI': 'WAJIB KTP 17+', 'LAKI-LAKI': penduduk.filter(p => isNew17YearsOld(p.tanggalLahir) && p.jenisKelamin === 'Laki-Laki').length, 'PEREMPUAN': penduduk.filter(p => isNew17YearsOld(p.tanggalLahir) && p.jenisKelamin === 'Perempuan').length, 'JUMLAH': '' });
      laporanData.push({ 'KATEGORI': 'PENDUDUK SEMENTARA', 'LAKI-LAKI': penduduk.filter(p => p.statusWarga !== 'TETAP' && p.jenisKelamin === 'Laki-Laki').length, 'PEREMPUAN': penduduk.filter(p => p.statusWarga !== 'TETAP' && p.jenisKelamin === 'Perempuan').length, 'JUMLAH': '' });
      laporanData.push({ 'KATEGORI': 'LAHIR', 'LAKI-LAKI': kejadian.filter(k => k.jenisKejadian === 'LAHIR' && k.penduduk?.jenisKelamin === 'Laki-Laki').length, 'PEREMPUAN': kejadian.filter(k => k.jenisKejadian === 'LAHIR' && k.penduduk?.jenisKelamin === 'Perempuan').length, 'JUMLAH': '' });
      laporanData.push({ 'KATEGORI': 'MENINGGAL', 'LAKI-LAKI': kejadian.filter(k => k.jenisKejadian === 'MENINGGAL' && k.penduduk?.jenisKelamin === 'Laki-Laki').length, 'PEREMPUAN': kejadian.filter(k => k.jenisKejadian === 'MENINGGAL' && k.penduduk?.jenisKelamin === 'Perempuan').length, 'JUMLAH': '' });
      laporanData.push({ 'KATEGORI': 'PINDAH', 'LAKI-LAKI': kejadian.filter(k => k.jenisKejadian === 'PINDAH' && k.penduduk?.jenisKelamin === 'Laki-Laki').length, 'PEREMPUAN': kejadian.filter(k => k.jenisKejadian === 'PINDAH' && k.penduduk?.jenisKelamin === 'Perempuan').length, 'JUMLAH': '' });
      laporanData.push({ 'KATEGORI': 'DATANG', 'LAKI-LAKI': kejadian.filter(k => k.jenisKejadian === 'DATANG' && k.penduduk?.jenisKelamin === 'Laki-Laki').length, 'PEREMPUAN': kejadian.filter(k => k.jenisKejadian === 'DATANG' && k.penduduk?.jenisKelamin === 'Perempuan').length, 'JUMLAH': '' });
      laporanData.push({ 'KATEGORI': '', 'LAKI-LAKI': '', 'PEREMPUAN': '', 'JUMLAH': '' });
      laporanData.push({ 'KATEGORI': 'USIA 0-11 BULAN', 'LAKI-LAKI': penduduk.filter(p => { const m = calculateAgeInMonths(p.tanggalLahir); return m >= 0 && m <= 11 && p.jenisKelamin === 'Laki-Laki'; }).length, 'PEREMPUAN': penduduk.filter(p => { const m = calculateAgeInMonths(p.tanggalLahir); return m >= 0 && m <= 11 && p.jenisKelamin === 'Perempuan'; }).length, 'JUMLAH': '' });
      
      for (let i = 1; i <= 100; i++) {
        const l = penduduk.filter(p => calculateAge(p.tanggalLahir) === i && p.jenisKelamin === 'Laki-Laki').length;
        const p = penduduk.filter(p => calculateAge(p.tanggalLahir) === i && p.jenisKelamin === 'Perempuan').length;
        if (l > 0 || p > 0) {
          laporanData.push({ 'KATEGORI': `USIA ${i} TAHUN`, 'LAKI-LAKI': l, 'PEREMPUAN': p, 'JUMLAH': '' });
        }
      }

      const ws = XLSX.utils.json_to_sheet(laporanData);
      XLSX.utils.book_append_sheet(workbook, ws, 'Laporan');
    }

    const buffer = XLSX.write(workbook, { type: 'buffer', bookType: 'xlsx' });
    
    return new NextResponse(buffer, {
      headers: {
        'Content-Type': 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet',
        'Content-Disposition': `attachment; filename="export-${type}-${new Date().toISOString().split('T')[0]}.xlsx"`
      }
    });
  } catch (error) {
    console.error('Error exporting data:', error);
    return NextResponse.json({ error: 'Gagal mengexport data' }, { status: 500 });
  }
}
