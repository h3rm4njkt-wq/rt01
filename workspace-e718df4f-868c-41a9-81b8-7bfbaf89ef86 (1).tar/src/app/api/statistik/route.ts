import { NextResponse } from 'next/server';
import { db } from '@/lib/db';

function calculateAge(birthDate: Date | null): number {
  if (!birthDate) return 0;
  const today = new Date();
  let age = today.getFullYear() - birthDate.getFullYear();
  const monthDiff = today.getMonth() - birthDate.getMonth();
  if (monthDiff < 0 || (monthDiff === 0 && today.getDate() < birthDate.getDate())) {
    age--;
  }
  return age;
}

function calculateAgeInMonths(birthDate: Date | null): number {
  if (!birthDate) return 0;
  const today = new Date();
  return (today.getFullYear() - birthDate.getFullYear()) * 12 + (today.getMonth() - birthDate.getMonth());
}

// Cek apakah sudah 17 tahun tepat
function isExactly17Years(birthDate: Date | null): boolean {
  return calculateAge(birthDate) === 17;
}

// Cek apakah baru 17 tahun (dalam bulan ini)
function isNew17YearsOld(birthDate: Date | null): boolean {
  if (!birthDate) return false;
  const today = new Date();
  const age = calculateAge(birthDate);
  if (age !== 17) return false;
  
  const thisYearBirthday = new Date(today.getFullYear(), birthDate.getMonth(), birthDate.getDate());
  const daysSinceBirthday = Math.floor((today.getTime() - thisYearBirthday.getTime()) / (1000 * 60 * 60 * 24));
  return daysSinceBirthday >= 0 && daysSinceBirthday <= 30;
}

// Cek apakah akan 17 tahun dalam bulan ini (untuk notifikasi)
function willBe17ThisMonth(birthDate: Date | null): boolean {
  if (!birthDate) return false;
  const today = new Date();
  const currentAge = calculateAge(birthDate);
  if (currentAge !== 16) return false;
  
  // Cek apakah ulang tahun 17 akan terjadi bulan ini
  const nextBirthday = new Date(today.getFullYear(), birthDate.getMonth(), birthDate.getDate());
  if (nextBirthday < today) {
    nextBirthday.setFullYear(nextBirthday.getFullYear() + 1);
  }
  
  const daysUntilBirthday = Math.floor((nextBirthday.getTime() - today.getTime()) / (1000 * 60 * 60 * 24));
  return daysUntilBirthday >= 0 && daysUntilBirthday <= 30;
}

export async function GET() {
  try {
    const penduduk = await db.penduduk.findMany({
      where: { aktif: true },
      include: {
        kartuKeluarga: true
      }
    });

    const kartuKeluarga = await db.kartuKeluarga.findMany({
      include: {
        penduduk: {
          where: { aktif: true, isKepalaKeluarga: true }
        }
      }
    });

    const kejadian = await db.kejadian.findMany({
      include: {
        penduduk: true
      }
    });

    // Kartu Keluarga stats
    const kkLakiLaki = kartuKeluarga.filter(kk => 
      kk.penduduk.some(p => p.isKepalaKeluarga && p.jenisKelamin === 'Laki-Laki')
    ).length;
    const kkPerempuan = kartuKeluarga.filter(kk => 
      kk.penduduk.some(p => p.isKepalaKeluarga && p.jenisKelamin === 'Perempuan')
    ).length;

    // Penduduk stats
    const pendudukLakiLaki = penduduk.filter(p => p.jenisKelamin === 'Laki-Laki').length;
    const pendudukPerempuan = penduduk.filter(p => p.jenisKelamin === 'Perempuan').length;

    // Umur 0-11 bulan
    const umur0to11BulanL = penduduk.filter(p => {
      const months = calculateAgeInMonths(p.tanggalLahir);
      return months >= 0 && months <= 11 && p.jenisKelamin === 'Laki-Laki';
    }).length;
    const umur0to11BulanP = penduduk.filter(p => {
      const months = calculateAgeInMonths(p.tanggalLahir);
      return months >= 0 && months <= 11 && p.jenisKelamin === 'Perempuan';
    }).length;

    // Umur per tahun (1-100 tahun)
    const umurPerTahun: { usia: number; l: number; p: number }[] = [];
    for (let i = 1; i <= 100; i++) {
      const l = penduduk.filter(p => calculateAge(p.tanggalLahir) === i && p.jenisKelamin === 'Laki-Laki').length;
      const p = penduduk.filter(p => calculateAge(p.tanggalLahir) === i && p.jenisKelamin === 'Perempuan').length;
      if (l > 0 || p > 0) {
        umurPerTahun.push({ usia: i, l, p });
      }
    }

    // Wajib KTP - hanya yang usia 17 tahun atau baru masuk 17 tahun
    // Yang baru 17 tahun (dalam 30 hari terakhir)
    const wajibKTPBaruL = penduduk.filter(p => 
      isNew17YearsOld(p.tanggalLahir) && p.jenisKelamin === 'Laki-Laki'
    );
    const wajibKTPBaruP = penduduk.filter(p => 
      isNew17YearsOld(p.tanggalLahir) && p.jenisKelamin === 'Perempuan'
    );

    // Semua yang berusia tepat 17 tahun
    const semua17TahunL = penduduk.filter(p => 
      isExactly17Years(p.tanggalLahir) && p.jenisKelamin === 'Laki-Laki'
    );
    const semua17TahunP = penduduk.filter(p => 
      isExactly17Years(p.tanggalLahir) && p.jenisKelamin === 'Perempuan'
    );

    // Yang akan 17 tahun dalam 30 hari
    const akan17TahunL = penduduk.filter(p => 
      willBe17ThisMonth(p.tanggalLahir) && p.jenisKelamin === 'Laki-Laki'
    );
    const akan17TahunP = penduduk.filter(p => 
      willBe17ThisMonth(p.tanggalLahir) && p.jenisKelamin === 'Perempuan'
    );

    // Penduduk sementara
    const pendudukSementaraL = penduduk.filter(p => 
      p.statusWarga !== 'TETAP' && p.jenisKelamin === 'Laki-Laki'
    ).length;
    const pendudukSementaraP = penduduk.filter(p => 
      p.statusWarga !== 'TETAP' && p.jenisKelamin === 'Perempuan'
    ).length;

    // Kejadian stats
    const kejadianLahir = kejadian.filter(k => k.jenisKejadian === 'LAHIR').length;
    const kejadianMeninggal = kejadian.filter(k => k.jenisKejadian === 'MENINGGAL').length;
    const kejadianPindah = kejadian.filter(k => k.jenisKejadian === 'PINDAH').length;
    const kejadianDatang = kejadian.filter(k => k.jenisKejadian === 'DATANG').length;

    // Kejadian dengan jenis kelamin
    const kejadianLahirL = kejadian.filter(k => 
      k.jenisKejadian === 'LAHIR' && k.penduduk?.jenisKelamin === 'Laki-Laki'
    ).length;
    const kejadianLahirP = kejadian.filter(k => 
      k.jenisKejadian === 'LAHIR' && k.penduduk?.jenisKelamin === 'Perempuan'
    ).length;
    const kejadianMeninggalL = kejadian.filter(k => 
      k.jenisKejadian === 'MENINGGAL' && k.penduduk?.jenisKelamin === 'Laki-Laki'
    ).length;
    const kejadianMeninggalP = kejadian.filter(k => 
      k.jenisKejadian === 'MENINGGAL' && k.penduduk?.jenisKelamin === 'Perempuan'
    ).length;
    const kejadianPindahL = kejadian.filter(k => 
      k.jenisKejadian === 'PINDAH' && k.penduduk?.jenisKelamin === 'Laki-Laki'
    ).length;
    const kejadianPindahP = kejadian.filter(k => 
      k.jenisKejadian === 'PINDAH' && k.penduduk?.jenisKelamin === 'Perempuan'
    ).length;
    const kejadianDatangL = kejadian.filter(k => 
      k.jenisKejadian === 'DATANG' && k.penduduk?.jenisKelamin === 'Laki-Laki'
    ).length;
    const kejadianDatangP = kejadian.filter(k => 
      k.jenisKejadian === 'DATANG' && k.penduduk?.jenisKelamin === 'Perempuan'
    ).length;

    // Format data penduduk 17 tahun untuk response
    const formatPenduduk17 = (list: typeof penduduk) => list.map(p => ({
      id: p.id,
      nik: p.nik,
      nama: p.nama,
      jenisKelamin: p.jenisKelamin,
      tanggalLahir: p.tanggalLahir,
      usia: calculateAge(p.tanggalLahir),
      noKK: p.kartuKeluarga?.noKK || '-',
      namaKK: p.kartuKeluarga?.namaKepalaKeluarga || '-',
    }));

    return NextResponse.json({
      kartuKeluarga: {
        total: kartuKeluarga.length,
        lakiLaki: kkLakiLaki,
        perempuan: kkPerempuan
      },
      penduduk: {
        total: penduduk.length,
        lakiLaki: pendudukLakiLaki,
        perempuan: pendudukPerempuan
      },
      umur: {
        bulanan: {
          '0-11': { l: umur0to11BulanL, p: umur0to11BulanP }
        },
        tahunan: umurPerTahun
      },
      // Wajib KTP = semua yang usia 17 tahun (baru masuk 17 tahun)
      wajibKTP: {
        lakiLaki: semua17TahunL.length,
        perempuan: semua17TahunP.length,
        total: semua17TahunL.length + semua17TahunP.length,
        list: {
          lakiLaki: formatPenduduk17(semua17TahunL),
          perempuan: formatPenduduk17(semua17TahunP)
        }
      },
      // Yang baru 17 tahun (dalam 30 hari terakhir)
      wajibKTPBaru: {
        lakiLaki: wajibKTPBaruL.length,
        perempuan: wajibKTPBaruP.length,
        total: wajibKTPBaruL.length + wajibKTPBaruP.length,
        list: {
          lakiLaki: formatPenduduk17(wajibKTPBaruL),
          perempuan: formatPenduduk17(wajibKTPBaruP)
        }
      },
      // Yang akan 17 tahun dalam 30 hari
      akan17Tahun: {
        lakiLaki: akan17TahunL.length,
        perempuan: akan17TahunP.length,
        total: akan17TahunL.length + akan17TahunP.length,
        list: {
          lakiLaki: formatPenduduk17(akan17TahunL),
          perempuan: formatPenduduk17(akan17TahunP)
        }
      },
      // Semua penduduk berusia tepat 17 tahun (sama dengan wajibKTP)
      penduduk17Tahun: {
        lakiLaki: semua17TahunL.length,
        perempuan: semua17TahunP.length,
        total: semua17TahunL.length + semua17TahunP.length,
        list: {
          lakiLaki: formatPenduduk17(semua17TahunL),
          perempuan: formatPenduduk17(semua17TahunP)
        }
      },
      pendudukSementara: {
        lakiLaki: pendudukSementaraL,
        perempuan: pendudukSementaraP
      },
      kejadian: {
        lahir: { total: kejadianLahir, l: kejadianLahirL, p: kejadianLahirP },
        meninggal: { total: kejadianMeninggal, l: kejadianMeninggalL, p: kejadianMeninggalP },
        pindah: { total: kejadianPindah, l: kejadianPindahL, p: kejadianPindahP },
        datang: { total: kejadianDatang, l: kejadianDatangL, p: kejadianDatangP }
      }
    });
  } catch (error) {
    console.error('Error fetching statistik:', error);
    return NextResponse.json({ error: 'Gagal mengambil data statistik' }, { status: 500 });
  }
}
