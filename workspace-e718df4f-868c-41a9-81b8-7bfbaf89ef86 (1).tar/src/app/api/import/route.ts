import { NextRequest, NextResponse } from 'next/server';
import { db } from '@/lib/db';
import * as XLSX from 'xlsx';

function parseExcelDate(value: unknown): Date | null {
  if (!value) return null;
  
  if (value instanceof Date) return value;
  
  if (typeof value === 'number') {
    const excelEpoch = new Date(1899, 11, 30);
    const date = new Date(excelEpoch.getTime() + value * 86400000);
    return date;
  }
  
  if (typeof value === 'string') {
    const parsed = new Date(value);
    if (!isNaN(parsed.getTime())) return parsed;
  }
  
  return null;
}

function normalizeJenisKelamin(value: unknown): string {
  const v = value?.toString().toUpperCase().trim() || '';
  if (v === 'L' || v === 'LAKI-LAKI' || v === 'LAKI LAKI') return 'Laki-Laki';
  if (v === 'P' || v === 'PEREMPUAN') return 'Perempuan';
  return 'Laki-Laki';
}

function normalizeStatusWarga(value: unknown): string {
  const v = value?.toString().toUpperCase().trim() || '';
  if (v === 'TETAP') return 'TETAP';
  if (v === 'KONTRAK') return 'KONTRAK';
  if (v === 'SEWA') return 'SEWA';
  if (v === 'MENUMPANG') return 'MENUMPANG';
  if (v === 'KOS') return 'KOS';
  return 'TETAP';
}

function normalizeStatusPerkawinan(value: unknown): string {
  const v = value?.toString().toUpperCase().trim() || '';
  if (v.includes('BELUM') || v === 'BELUM MENIKAH') return 'BELUM MENIKAH';
  if (v.includes('KAWIN') && !v.includes('CERAI')) return 'KAWIN';
  if (v.includes('CERAI HIDUP')) return 'CERAI HIDUP';
  if (v.includes('CERAI MATI')) return 'CERAI MATI';
  return 'BELUM MENIKAH';
}

function safeString(val: unknown): string {
  if (val === null || val === undefined) return '';
  return val.toString().trim();
}

function safeNumberString(val: unknown): string {
  if (val === null || val === undefined) return '';
  if (typeof val === 'number') {
    return Math.round(val).toString();
  }
  return val.toString().trim();
}

export async function POST(request: NextRequest) {
  try {
    const formData = await request.formData();
    const file = formData.get('file') as File;
    
    if (!file) {
      return NextResponse.json({ error: 'File tidak ditemukan' }, { status: 400 });
    }

    const buffer = Buffer.from(await file.arrayBuffer());
    
    const workbook = XLSX.read(buffer, { type: 'buffer' });
    const sheetName = workbook.SheetNames[0];
    const worksheet = workbook.Sheets[sheetName];
    
    // Get the range of the sheet
    const range = XLSX.utils.decode_range(worksheet['!ref'] || 'A1');
    
    let currentNoKK = '';
    let currentKKId: string | null = null;
    let importedKK = 0;
    let importedPenduduk = 0;
    const errors: string[] = [];

    // Clear existing data first
    await db.penduduk.deleteMany({});
    await db.kartuKeluarga.deleteMany({});

    // Start from row 4 (skip 2 header rows), data starts at Excel row 4
    // range.s.r is the start row from the range (B2:W366 means s.r = 1 for row 2)
    // We need to skip rows 2 and 3 (headers), so start from row 4 which is s.r + 2
    for (let rowNum = range.s.r + 2; rowNum <= range.e.r; rowNum++) {
      // Get cell values
      const getCell = (col: number) => {
        const cellAddress = XLSX.utils.encode_cell({ r: rowNum, c: col });
        const cell = worksheet[cellAddress];
        if (!cell) return null;
        return cell.v;
      };
      
      // Column indices:
      // 0: empty, 1: NO. KK, 2: Nama Lengkap, 3: NIK, 4: Jenis Kelamin
      // 5: Tempat Lahir, 6: Tanggal Lahir, 7: Agama, 8: Pendidikan
      // 9: Jenis Pekerjaan, 10: Status Perkawinan, 11: Kewarganegaraan
      // 12: Status Warga, 13: Nama Ayah, 14: Nama Ibu, 15: Nama Panggilan
      
      const noKK = safeNumberString(getCell(1));
      const nama = safeString(getCell(2));
      const nik = safeNumberString(getCell(3));
      
      // Skip empty rows (rows without nama)
      if (!nama) continue;
      
      // If this row has No KK, it's a Head of Family
      if (noKK) {
        currentNoKK = noKK;
        
        // Create new KK
        try {
          const newKK = await db.kartuKeluarga.create({
            data: {
              noKK: noKK,
              namaKepalaKeluarga: nama,
            }
          });
          currentKKId = newKK.id;
          importedKK++;
        } catch (e) {
          errors.push(`Row ${rowNum + 1}: Gagal membuat KK ${noKK}`);
          continue;
        }
      }
      
      // Skip rows without NIK (required)
      if (!nik) continue;
      
      // Check if penduduk already exists
      const existingPenduduk = await db.penduduk.findUnique({
        where: { nik: nik }
      });

      if (!existingPenduduk) {
        try {
          await db.penduduk.create({
            data: {
              nik: nik,
              nama: nama,
              jenisKelamin: normalizeJenisKelamin(getCell(4)),
              tempatLahir: safeString(getCell(5)),
              tanggalLahir: parseExcelDate(getCell(6)),
              agama: safeString(getCell(7)).toUpperCase() || 'ISLAM',
              pendidikan: safeString(getCell(8)).toUpperCase(),
              pekerjaan: safeString(getCell(9)).toUpperCase(),
              statusPerkawinan: normalizeStatusPerkawinan(getCell(10)),
              kewarganegaraan: safeString(getCell(11)).toUpperCase() || 'WNI',
              statusWarga: normalizeStatusWarga(getCell(12)),
              namaAyah: safeString(getCell(13)),
              namaIbu: safeString(getCell(14)),
              namaPanggilan: safeString(getCell(15)),
              noKKId: currentKKId,
              isKepalaKeluarga: !!noKK,
            }
          });
          importedPenduduk++;
        } catch (e) {
          errors.push(`Row ${rowNum + 1}: Gagal import ${nama} (${nik})`);
        }
      }
    }

    return NextResponse.json({
      success: true,
      importedKK,
      importedPenduduk,
      totalRows: importedPenduduk,
      errors: errors.slice(0, 10),
    });
  } catch (error) {
    console.error('Error importing data:', error);
    return NextResponse.json({ 
      error: 'Gagal mengimport data: ' + (error instanceof Error ? error.message : String(error)) 
    }, { status: 500 });
  }
}
