import { NextRequest, NextResponse } from 'next/server';
import { db } from '@/lib/db';

export async function GET(
  request: NextRequest,
  { params }: { params: Promise<{ id: string }> }
) {
  try {
    const { id } = await params;
    
    const kejadian = await db.kejadian.findUnique({
      where: { id },
      include: {
        penduduk: true,
        kartuKeluarga: true
      }
    });

    if (!kejadian) {
      return NextResponse.json({ error: 'Kejadian tidak ditemukan' }, { status: 404 });
    }

    return NextResponse.json(kejadian);
  } catch (error) {
    console.error('Error fetching kejadian:', error);
    return NextResponse.json({ error: 'Gagal mengambil data kejadian' }, { status: 500 });
  }
}

export async function PUT(
  request: NextRequest,
  { params }: { params: Promise<{ id: string }> }
) {
  try {
    const { id } = await params;
    const data = await request.json();

    const kejadian = await db.kejadian.update({
      where: { id },
      data: {
        tanggalKejadian: new Date(data.tanggalKejadian),
        keterangan: data.keterangan || null,
      }
    });

    return NextResponse.json(kejadian);
  } catch (error) {
    console.error('Error updating kejadian:', error);
    return NextResponse.json({ error: 'Gagal mengupdate data kejadian' }, { status: 500 });
  }
}

export async function DELETE(
  request: NextRequest,
  { params }: { params: Promise<{ id: string }> }
) {
  try {
    const { id } = await params;
    
    const kejadian = await db.kejadian.findUnique({
      where: { id },
      include: { penduduk: true }
    });

    if (kejadian && kejadian.penduduk) {
      if (kejadian.jenisKejadian === 'MENINGGAL' || kejadian.jenisKejadian === 'PINDAH') {
        await db.penduduk.update({
          where: { id: kejadian.penduduk.id },
          data: { aktif: true }
        });
      }
    }

    await db.kejadian.delete({
      where: { id }
    });

    return NextResponse.json({ success: true });
  } catch (error) {
    console.error('Error deleting kejadian:', error);
    return NextResponse.json({ error: 'Gagal menghapus data kejadian' }, { status: 500 });
  }
}
