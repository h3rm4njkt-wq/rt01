import { NextRequest, NextResponse } from 'next/server';
import { db } from '@/lib/db';

export async function GET(request: NextRequest) {
  try {
    const { searchParams } = new URL(request.url);
    const jenis = searchParams.get('jenis');
    
    const where: { jenisKejadian?: string } = {};
    if (jenis) {
      where.jenisKejadian = jenis;
    }

    const kejadian = await db.kejadian.findMany({
      where,
      include: {
        penduduk: {
          select: {
            id: true,
            nik: true,
            nama: true,
            jenisKelamin: true,
          }
        },
        kartuKeluarga: {
          select: {
            id: true,
            noKK: true,
            namaKepalaKeluarga: true,
          }
        }
      },
      orderBy: { tanggalKejadian: 'desc' }
    });

    return NextResponse.json(kejadian);
  } catch (error) {
    console.error('Error fetching kejadian:', error);
    return NextResponse.json({ error: 'Gagal mengambil data kejadian' }, { status: 500 });
  }
}

export async function POST(request: NextRequest) {
  try {
    const data = await request.json();
    const { jenisKejadian, pendudukId, noKKId, tanggalKejadian, keterangan, pendudukBaru, kkBaru } = data;

    let finalPendudukId = pendudukId;
    let finalNoKKId = noKKId;

    if (jenisKejadian === 'LAHIR') {
      if (pendudukBaru) {
        const newPenduduk = await db.penduduk.create({
          data: {
            nik: pendudukBaru.nik,
            nama: pendudukBaru.nama,
            jenisKelamin: pendudukBaru.jenisKelamin,
            tempatLahir: pendudukBaru.tempatLahir || '',
            tanggalLahir: pendudukBaru.tanggalLahir ? new Date(pendudukBaru.tanggalLahir) : new Date(),
            agama: pendudukBaru.agama || 'ISLAM',
            pendidikan: 'TIDAK/BELUM SEKOLAH',
            pekerjaan: 'BELUM/TIDAKBEKERJA',
            statusPerkawinan: 'BELUM MENIKAH',
            statusWarga: 'TETAP',
            namaAyah: pendudukBaru.namaAyah || '',
            namaIbu: pendudukBaru.namaIbu || '',
            noKKId: noKKId,
          }
        });
        finalPendudukId = newPenduduk.id;
      }
    } else if (jenisKejadian === 'DATANG') {
      if (kkBaru && !noKKId) {
        const newKK = await db.kartuKeluarga.create({
          data: {
            noKK: kkBaru.noKK,
            namaKepalaKeluarga: kkBaru.namaKepalaKeluarga,
            alamat: kkBaru.alamat || '',
          }
        });
        finalNoKKId = newKK.id;
        
        if (pendudukBaru) {
          for (const member of pendudukBaru) {
            const newPenduduk = await db.penduduk.create({
              data: {
                nik: member.nik,
                nama: member.nama,
                jenisKelamin: member.jenisKelamin,
                tempatLahir: member.tempatLahir || '',
                tanggalLahir: member.tanggalLahir ? new Date(member.tanggalLahir) : null,
                agama: member.agama || 'ISLAM',
                pendidikan: member.pendidikan || '',
                pekerjaan: member.pekerjaan || '',
                statusPerkawinan: member.statusPerkawinan || 'BELUM MENIKAH',
                statusWarga: 'TETAP',
                namaAyah: member.namaAyah || '',
                namaIbu: member.namaIbu || '',
                namaPanggilan: member.namaPanggilan || '',
                bpjs: member.bpjs || 'Tidak',
                noKKId: finalNoKKId,
                isKepalaKeluarga: member.isKepalaKeluarga || false,
              }
            });
            if (member.isKepalaKeluarga) {
              finalPendudukId = newPenduduk.id;
            }
          }
        }
      } else if (pendudukBaru && noKKId) {
        // Handle multiple penduduk when adding to existing KK
        const pendudukArray = Array.isArray(pendudukBaru) ? pendudukBaru : [pendudukBaru];
        let firstPendudukId = null;
        
        for (const member of pendudukArray) {
          const newPenduduk = await db.penduduk.create({
            data: {
              nik: member.nik,
              nama: member.nama,
              jenisKelamin: member.jenisKelamin,
              tempatLahir: member.tempatLahir || '',
              tanggalLahir: member.tanggalLahir ? new Date(member.tanggalLahir) : null,
              agama: member.agama || 'ISLAM',
              pendidikan: member.pendidikan || '',
              pekerjaan: member.pekerjaan || '',
              statusPerkawinan: member.statusPerkawinan || 'BELUM MENIKAH',
              statusWarga: 'TETAP',
              namaAyah: member.namaAyah || '',
              namaIbu: member.namaIbu || '',
              namaPanggilan: member.namaPanggilan || '',
              bpjs: member.bpjs || 'Tidak',
              noKKId: noKKId,
            }
          });
          if (!firstPendudukId) {
            firstPendudukId = newPenduduk.id;
          }
        }
        finalPendudukId = firstPendudukId;
      }
    } else if (jenisKejadian === 'MENINGGAL' || jenisKejadian === 'PINDAH') {
      if (pendudukId) {
        await db.penduduk.update({
          where: { id: pendudukId },
          data: { aktif: false }
        });
      } else if (noKKId && data.pindahSemua) {
        await db.penduduk.updateMany({
          where: { noKKId },
          data: { aktif: false }
        });
      }
    }

    const kejadian = await db.kejadian.create({
      data: {
        jenisKejadian,
        pendudukId: finalPendudukId,
        noKKId: finalNoKKId,
        tanggalKejadian: tanggalKejadian ? new Date(tanggalKejadian) : new Date(),
        keterangan: keterangan || '',
      },
      include: {
        penduduk: true,
        kartuKeluarga: true,
      }
    });

    return NextResponse.json(kejadian);
  } catch (error) {
    console.error('Error creating kejadian:', error);
    return NextResponse.json({ error: 'Gagal membuat data kejadian' }, { status: 500 });
  }
}
