import { NextRequest, NextResponse } from 'next/server';
import { db } from '@/lib/db';

export async function GET() {
  try {
    const settings = await db.settings.findFirst();
    
    if (!settings) {
      const newSettings = await db.settings.create({
        data: {
          ketuaRT: 'Herman Gozali',
          rt: '001',
          rw: '002',
          kelurahan: 'Sukamaju',
          kecamatan: 'Cibungbulang',
          kabupaten: 'Bogor',
          provinsi: 'Jawa Barat',
          alamat: 'KP. CEMPLANG, KELURAHAN SUKAMAJU, KECAMATAN CIBUNGBULANG, KABUPATEN BOGOR, PROVINSI JAWA BARAT, KODE POS 16630',
          kodePos: '16630',
        }
      });
      return NextResponse.json(newSettings);
    }
    
    return NextResponse.json(settings);
  } catch (error) {
    console.error('Error fetching settings:', error);
    return NextResponse.json({ error: 'Gagal mengambil pengaturan' }, { status: 500 });
  }
}

export async function PUT(request: NextRequest) {
  try {
    const data = await request.json();
    
    const settings = await db.settings.findFirst();
    
    if (!settings) {
      const newSettings = await db.settings.create({
        data: {
          ketuaRT: data.ketuaRT || 'Herman Gozali',
          rt: data.rt || '001',
          rw: data.rw || '002',
          kelurahan: data.kelurahan || 'Sukamaju',
          kecamatan: data.kecamatan || 'Cibungbulang',
          kabupaten: data.kabupaten || 'Bogor',
          provinsi: data.provinsi || 'Jawa Barat',
          alamat: data.alamat || 'KP. CEMPLANG, KELURAHAN SUKAMAJU, KECAMATAN CIBUNGBULANG, KABUPATEN BOGOR, PROVINSI JAWA BARAT, KODE POS 16630',
          kodePos: data.kodePos || '16630',
        }
      });
      return NextResponse.json(newSettings);
    }
    
    const updated = await db.settings.update({
      where: { id: settings.id },
      data: {
        ketuaRT: data.ketuaRT,
        rt: data.rt,
        rw: data.rw,
        kelurahan: data.kelurahan,
        kecamatan: data.kecamatan,
        kabupaten: data.kabupaten,
        provinsi: data.provinsi,
        alamat: data.alamat,
        kodePos: data.kodePos,
      }
    });
    
    return NextResponse.json(updated);
  } catch (error) {
    console.error('Error updating settings:', error);
    return NextResponse.json({ error: 'Gagal mengupdate pengaturan' }, { status: 500 });
  }
}
