import { NextRequest, NextResponse } from 'next/server';
import { db } from '@/lib/db';

export async function GET(
  request: NextRequest,
  { params }: { params: Promise<{ id: string }> }
) {
  try {
    const { id } = await params;
    const penduduk = await db.penduduk.findUnique({
      where: { id },
      include: {
        kartuKeluarga: true
      }
    });

    if (!penduduk) {
      return NextResponse.json({ error: 'Penduduk tidak ditemukan' }, { status: 404 });
    }

    return NextResponse.json(penduduk);
  } catch (error) {
    console.error('Error fetching penduduk:', error);
    return NextResponse.json({ error: 'Gagal mengambil data penduduk' }, { status: 500 });
  }
}

export async function PUT(
  request: NextRequest,
  { params }: { params: Promise<{ id: string }> }
) {
  try {
    const { id } = await params;
    const data = await request.json();
    
    // Validasi NIK harus 16 digit
    if (data.nik && !/^[0-9]{16}$/.test(data.nik)) {
      return NextResponse.json({ error: 'NIK harus 16 digit angka' }, { status: 400 });
    }
    
    // Cek duplikat NIK (exclude current record)
    if (data.nik) {
      const existingPenduduk = await db.penduduk.findFirst({
        where: { 
          nik: data.nik,
          NOT: { id }
        }
      });
      if (existingPenduduk) {
        return NextResponse.json({ error: 'NIK sudah terdaftar' }, { status: 400 });
      }
    }
    
    // Cek duplikat NIK anggota baru
    if (data.anggotaBaru && Array.isArray(data.anggotaBaru) && data.anggotaBaru.length > 0) {
      for (const anggota of data.anggotaBaru) {
        if (anggota.nik) {
          if (!/^[0-9]{16}$/.test(anggota.nik)) {
            return NextResponse.json({ error: `NIK ${anggota.nama || anggota.nik} harus 16 digit angka` }, { status: 400 });
          }
          const existingAnggota = await db.penduduk.findUnique({
            where: { nik: anggota.nik }
          });
          if (existingAnggota) {
            return NextResponse.json({ error: `NIK ${anggota.nik} sudah terdaftar` }, { status: 400 });
          }
        }
      }
    }

    const penduduk = await db.penduduk.update({
      where: { id },
      data: {
        nik: data.nik,
        nama: data.nama,
        jenisKelamin: data.jenisKelamin,
        tempatLahir: data.tempatLahir || '',
        tanggalLahir: data.tanggalLahir ? new Date(data.tanggalLahir) : null,
        agama: data.agama || 'ISLAM',
        pendidikan: data.pendidikan || '',
        pekerjaan: data.pekerjaan || '',
        statusPerkawinan: data.statusPerkawinan || 'BELUM MENIKAH',
        kewarganegaraan: data.kewarganegaraan || 'WNI',
        statusWarga: data.statusWarga || 'TETAP',
        namaAyah: data.namaAyah || '',
        namaIbu: data.namaIbu || '',
        namaPanggilan: data.namaPanggilan || '',
        bpjs: data.bpjs || 'Tidak',
        noKKId: data.noKKId || null,
        isKepalaKeluarga: data.isKepalaKeluarga || false,
      }
    });

    // Tambah anggota keluarga baru jika ada
    if (data.anggotaBaru && Array.isArray(data.anggotaBaru) && data.anggotaBaru.length > 0) {
      for (const anggota of data.anggotaBaru) {
        if (anggota.nik && anggota.nama) {
          await db.penduduk.create({
            data: {
              nik: anggota.nik,
              nama: anggota.nama,
              jenisKelamin: anggota.jenisKelamin || 'Laki-Laki',
              tempatLahir: anggota.tempatLahir || '',
              tanggalLahir: anggota.tanggalLahir ? new Date(anggota.tanggalLahir) : null,
              agama: 'ISLAM',
              pendidikan: '',
              pekerjaan: '',
              statusPerkawinan: 'BELUM MENIKAH',
              kewarganegaraan: 'WNI',
              statusWarga: data.statusWarga || 'TETAP',
              namaAyah: anggota.namaAyah || '',
              namaIbu: anggota.namaIbu || '',
              namaPanggilan: anggota.namaPanggilan || '',
              bpjs: anggota.bpjs || 'Tidak',
              noKKId: data.noKKId || null,
              isKepalaKeluarga: false,
            }
          });
        }
      }
    }

    return NextResponse.json(penduduk);
  } catch (error) {
    console.error('Error updating penduduk:', error);
    return NextResponse.json({ error: 'Gagal mengupdate data penduduk' }, { status: 500 });
  }
}

export async function DELETE(
  request: NextRequest,
  { params }: { params: Promise<{ id: string }> }
) {
  try {
    const { id } = await params;
    
    await db.penduduk.update({
      where: { id },
      data: { aktif: false }
    });

    return NextResponse.json({ success: true });
  } catch (error) {
    console.error('Error deleting penduduk:', error);
    return NextResponse.json({ error: 'Gagal menghapus data penduduk' }, { status: 500 });
  }
}
