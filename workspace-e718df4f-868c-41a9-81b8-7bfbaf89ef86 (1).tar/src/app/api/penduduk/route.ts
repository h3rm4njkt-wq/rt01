import { NextRequest, NextResponse } from 'next/server';
import { db } from '@/lib/db';

export async function GET(request: NextRequest) {
  try {
    const { searchParams } = new URL(request.url);
    const noKKId = searchParams.get('noKKId');
    
    const where: { aktif: boolean; noKKId?: string } = { aktif: true };
    if (noKKId) {
      where.noKKId = noKKId;
    }

    const penduduk = await db.penduduk.findMany({
      where,
      include: {
        kartuKeluarga: {
          select: {
            noKK: true,
            namaKepalaKeluarga: true,
          }
        }
      },
      orderBy: [
        { noKKId: 'asc' },
        { isKepalaKeluarga: 'desc' },
        { nama: 'asc' }
      ]
    });

    return NextResponse.json(penduduk);
  } catch (error) {
    console.error('Error fetching penduduk:', error);
    return NextResponse.json({ error: 'Gagal mengambil data penduduk' }, { status: 500 });
  }
}

export async function POST(request: NextRequest) {
  try {
    const data = await request.json();
    
    // Validasi NIK harus 16 digit
    if (data.nik && !/^[0-9]{16}$/.test(data.nik)) {
      return NextResponse.json({ error: 'NIK harus 16 digit angka' }, { status: 400 });
    }
    
    const existingPenduduk = await db.penduduk.findUnique({
      where: { nik: data.nik }
    });

    if (existingPenduduk) {
      return NextResponse.json({ error: 'NIK sudah terdaftar' }, { status: 400 });
    }

    const penduduk = await db.penduduk.create({
      data: {
        nik: data.nik,
        nama: data.nama,
        jenisKelamin: data.jenisKelamin,
        tempatLahir: data.tempatLahir || '',
        tanggalLahir: data.tanggalLahir ? new Date(data.tanggalLahir) : null,
        agama: data.agama || 'ISLAM',
        pendidikan: data.pendidikan || '',
        pekerjaan: data.pekerjaan || '',
        statusPerkawinan: data.statusPerkawinan || 'BELUM MENIKAH',
        kewarganegaraan: data.kewarganegaraan || 'WNI',
        statusWarga: data.statusWarga || 'TETAP',
        namaAyah: data.namaAyah || '',
        namaIbu: data.namaIbu || '',
        namaPanggilan: data.namaPanggilan || '',
        bpjs: data.bpjs || 'Tidak',
        noKKId: data.noKKId || null,
        isKepalaKeluarga: data.isKepalaKeluarga || false,
      }
    });

    return NextResponse.json(penduduk);
  } catch (error) {
    console.error('Error creating penduduk:', error);
    return NextResponse.json({ error: 'Gagal membuat data penduduk' }, { status: 500 });
  }
}
