'use client'

import { useState, useEffect } from 'react'
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs'
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card'
import { Button } from '@/components/ui/button'
import { BerandaTab } from '@/components/BerandaTab'
import { KartuKeluargaTab } from '@/components/KartuKeluargaTab'
import { PendudukTab } from '@/components/PendudukTab'
import { KejadianTab } from '@/components/KejadianTab'
import { LaporanTab } from '@/components/LaporanTab'
import { Users, Home as HomeIcon, User, FileText, BarChart3 } from 'lucide-react'

export default function HomePage() {
  const [activeTab, setActiveTab] = useState('beranda')

  return (
    <div className="min-h-screen bg-gray-50">
      {/* Header */}
      <header className="bg-emerald-700 text-white shadow-lg sticky top-0 z-50 no-print">
        <div className="max-w-7xl mx-auto px-3 py-3">
          <div className="flex items-center justify-between">
            <div>
              <h1 className="text-lg md:text-xl font-bold">SISTEM DATA KEPENDUDUKAN</h1>
              <p className="text-xs md:text-sm text-emerald-100">
                RT.001 / RW.002 Sukamaju, Cibungbulang, Bogor, Jawa Barat
              </p>
              <p className="text-xs text-emerald-200">Ketua RT: Herman Gozali</p>
            </div>
            <div className="hidden md:flex items-center gap-2 bg-emerald-600 px-3 py-1 rounded-lg">
              <Users className="h-5 w-5" />
              <span className="text-sm">SIAK RT</span>
            </div>
          </div>
        </div>
      </header>

      {/* Main Content */}
      <main className="max-w-7xl mx-auto px-2 py-3">
        <Tabs value={activeTab} onValueChange={setActiveTab} className="w-full">
          <TabsList className="grid w-full grid-cols-5 h-auto p-1 bg-white shadow rounded-lg mb-4 no-print">
            <TabsTrigger value="beranda" className="flex flex-col items-center gap-1 py-2 text-xs md:text-sm data-[state=active]:bg-emerald-600 data-[state=active]:text-white">
              <HomeIcon className="h-4 w-4" />
              <span className="hidden sm:inline">Beranda</span>
              <span className="sm:hidden">Beranda</span>
            </TabsTrigger>
            <TabsTrigger value="kartu-keluarga" className="flex flex-col items-center gap-1 py-2 text-xs md:text-sm data-[state=active]:bg-emerald-600 data-[state=active]:text-white">
              <Users className="h-4 w-4" />
              <span>Kartu Keluarga</span>
            </TabsTrigger>
            <TabsTrigger value="penduduk" className="flex flex-col items-center gap-1 py-2 text-xs md:text-sm data-[state=active]:bg-emerald-600 data-[state=active]:text-white">
              <User className="h-4 w-4" />
              <span className="hidden sm:inline">Penduduk</span>
              <span className="sm:hidden">Penduduk</span>
            </TabsTrigger>
            <TabsTrigger value="kejadian" className="flex flex-col items-center gap-1 py-2 text-xs md:text-sm data-[state=active]:bg-emerald-600 data-[state=active]:text-white">
              <FileText className="h-4 w-4" />
              <span className="hidden sm:inline">Kejadian</span>
              <span className="sm:hidden">Kejadian</span>
            </TabsTrigger>
            <TabsTrigger value="laporan" className="flex flex-col items-center gap-1 py-2 text-xs md:text-sm data-[state=active]:bg-emerald-600 data-[state=active]:text-white">
              <BarChart3 className="h-4 w-4" />
              <span className="hidden sm:inline">Laporan</span>
              <span className="sm:hidden">Laporan</span>
            </TabsTrigger>
          </TabsList>

          <TabsContent value="beranda" className="mt-0">
            <BerandaTab />
          </TabsContent>

          <TabsContent value="kartu-keluarga" className="mt-0">
            <KartuKeluargaTab />
          </TabsContent>

          <TabsContent value="penduduk" className="mt-0">
            <PendudukTab />
          </TabsContent>

          <TabsContent value="kejadian" className="mt-0">
            <KejadianTab />
          </TabsContent>

          <TabsContent value="laporan" className="mt-0">
            <LaporanTab />
          </TabsContent>
        </Tabs>
      </main>

      {/* Footer */}
      <footer className="bg-gray-800 text-white py-3 mt-6 no-print">
        <div className="max-w-7xl mx-auto px-3 text-center text-xs">
          <p>Sistem Data Kependudukan RT.001/RW.002 Sukamaju</p>
          <p className="text-gray-400 mt-1">© {new Date().getFullYear()} - Dibuat untuk Kepentingan Administrasi RT</p>
        </div>
      </footer>
    </div>
  )
}
