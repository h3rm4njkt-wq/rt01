'use client'

import { useState, useEffect } from 'react'
import { Button } from '@/components/ui/button'
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card'
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from '@/components/ui/table'
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from '@/components/ui/select'
import { Download, Printer, Edit3 } from 'lucide-react'
import { Textarea } from '@/components/ui/textarea'

interface Statistik {
  kartuKeluarga: { total: number; lakiLaki: number; perempuan: number }
  penduduk: { total: number; lakiLaki: number; perempuan: number }
  umur: {
    bulanan: { '0-11': { l: number; p: number } }
    tahunan: { usia: number; l: number; p: number }[]
  }
  wajibKTP: { lakiLaki: number; perempuan: number; total: number }
  penduduk17Tahun: {
    lakiLaki: number
    perempuan: number
    total: number
  }
  pendudukSementara: { lakiLaki: number; perempuan: number }
  kejadian: {
    lahir: { total: number; l: number; p: number }
    meninggal: { total: number; l: number; p: number }
    pindah: { total: number; l: number; p: number }
    datang: { total: number; l: number; p: number }
  }
}

interface Settings {
  ketuaRT: string
  rt: string
  rw: string
  kelurahan: string
  kecamatan: string
  kabupaten: string
  provinsi: string
  alamat: string
  kodePos: string
  tanggalPembuatan: string
}

const BULAN_OPTIONS = [
  'Januari', 'Februari', 'Maret', 'April', 'Mei', 'Juni',
  'Juli', 'Agustus', 'September', 'Oktober', 'November', 'Desember'
]

export function LaporanTab() {
  const [statistik, setStatistik] = useState<Statistik | null>(null)
  const [settings, setSettings] = useState<Settings | null>(null)
  const [loading, setLoading] = useState(true)
  const [selectedDate, setSelectedDate] = useState({
    tanggal: new Date().getDate().toString(),
    bulan: BULAN_OPTIONS[new Date().getMonth()],
    tahun: new Date().getFullYear().toString(),
  })
  const [keteranganPerubahan, setKeteranganPerubahan] = useState('')
  const [realisasiKTPKK, setRealisasiKTPKK] = useState('')

  useEffect(() => {
    fetchData()
  }, [])

  const fetchData = async () => {
    try {
      const [statRes, settingsRes] = await Promise.all([
        fetch('/api/statistik'),
        fetch('/api/settings'),
      ])
      const statData = await statRes.json()
      const settingsData = await settingsRes.json()
      setStatistik(statData)
      setSettings(settingsData)
    } catch (error) {
      console.error('Error fetching data:', error)
    } finally {
      setLoading(false)
    }
  }

  const handlePrint = () => {
    window.print()
  }

  const handleExport = () => {
    window.open('/api/export?type=laporan', '_blank')
  }

  const formatDatePembuatan = (date: string) => {
    if (!date) return '-'
    const d = new Date(date)
    return `${d.getDate()} ${BULAN_OPTIONS[d.getMonth()]} ${d.getFullYear()}`
  }

  if (loading) {
    return (
      <div className="flex items-center justify-center h-64">
        <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-emerald-600"></div>
      </div>
    )
  }

  const tahunOptions: string[] = []
  for (let i = 2020; i <= new Date().getFullYear() + 1; i++) {
    tahunOptions.push(i.toString())
  }

  return (
    <div className="space-y-4">
      {/* Date Selector */}
      <div className="flex flex-wrap gap-2 items-end no-print">
        <div>
          <label className="text-sm text-gray-500">Tanggal</label>
          <Select value={selectedDate.tanggal} onValueChange={(v) => setSelectedDate({ ...selectedDate, tanggal: v })}>
            <SelectTrigger className="w-20">
              <SelectValue />
            </SelectTrigger>
            <SelectContent>
              {Array.from({ length: 31 }, (_, i) => (
                <SelectItem key={i + 1} value={(i + 1).toString()}>
                  {i + 1}
                </SelectItem>
              ))}
            </SelectContent>
          </Select>
        </div>
        <div>
          <label className="text-sm text-gray-500">Bulan</label>
          <Select value={selectedDate.bulan} onValueChange={(v) => setSelectedDate({ ...selectedDate, bulan: v })}>
            <SelectTrigger className="w-32">
              <SelectValue />
            </SelectTrigger>
            <SelectContent>
              {BULAN_OPTIONS.map((b) => (
                <SelectItem key={b} value={b}>{b}</SelectItem>
              ))}
            </SelectContent>
          </Select>
        </div>
        <div>
          <label className="text-sm text-gray-500">Tahun</label>
          <Select value={selectedDate.tahun} onValueChange={(v) => setSelectedDate({ ...selectedDate, tahun: v })}>
            <SelectTrigger className="w-24">
              <SelectValue />
            </SelectTrigger>
            <SelectContent>
              {tahunOptions.map((t) => (
                <SelectItem key={t} value={t}>{t}</SelectItem>
              ))}
            </SelectContent>
          </Select>
        </div>
        <Button variant="outline" onClick={handlePrint}>
          <Printer className="h-4 w-4 mr-2" />
          Print
        </Button>
        <Button variant="outline" onClick={handleExport}>
          <Download className="h-4 w-4 mr-2" />
          Export
        </Button>
      </div>

      {/* Report Content */}
      <Card className="print-area">
        <CardContent className="p-4 md:p-6">
          {/* Header */}
          <div className="text-center mb-6">
            <h1 className="text-lg md:text-xl font-bold">LAPORAN DATA PENDUDUK</h1>
            <p className="text-sm">Kelurahan {settings?.kelurahan || 'Sukamaju'}, Kecamatan {settings?.kecamatan || 'Cibungbulang'}</p>
            <p className="text-sm">Kabupaten {settings?.kabupaten || 'Bogor'}, Provinsi {settings?.provinsi || 'Jawa Barat'}</p>
            <p className="text-sm font-semibold">RT. {settings?.rt || '001'} / RW. {settings?.rw || '002'}</p>
            <p className="text-sm mt-1">Tahun: {selectedDate.tahun}</p>
            <p className="text-xs text-gray-500 mt-2">
              Tanggal Pembuatan Program: {formatDatePembuatan(settings?.tanggalPembuatan || '')}
            </p>
          </div>

          {/* Main Tables */}
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-4">
            {/* Left Table - Umur Per Tahun */}
            <div>
              <Table className="border text-xs md:text-sm">
                <TableHeader>
                  <TableRow className="bg-gray-100">
                    <TableHead className="border font-semibold">USIA</TableHead>
                    <TableHead className="border text-center font-semibold">LAKI-LAKI</TableHead>
                    <TableHead className="border text-center font-semibold">PEREMPUAN</TableHead>
                  </TableRow>
                </TableHeader>
                <TableBody>
                  <TableRow>
                    <TableCell className="border font-medium">0-11 BLN</TableCell>
                    <TableCell className="border text-center">{statistik?.umur.bulanan['0-11'].l || 0}</TableCell>
                    <TableCell className="border text-center">{statistik?.umur.bulanan['0-11'].p || 0}</TableCell>
                  </TableRow>
                  {statistik?.umur.tahunan.map((item) => (
                    <TableRow key={item.usia}>
                      <TableCell className="border">{item.usia} Tahun</TableCell>
                      <TableCell className="border text-center">{item.l}</TableCell>
                      <TableCell className="border text-center">{item.p}</TableCell>
                    </TableRow>
                  ))}
                  <TableRow className="bg-gray-50 font-semibold">
                    <TableCell className="border">JUMLAH</TableCell>
                    <TableCell className="border text-center">{statistik?.penduduk.lakiLaki || 0}</TableCell>
                    <TableCell className="border text-center">{statistik?.penduduk.perempuan || 0}</TableCell>
                  </TableRow>
                </TableBody>
              </Table>
            </div>

            {/* Right Tables */}
            <div className="space-y-4">
              {/* Penduduk */}
              <Table className="border text-xs md:text-sm">
                <TableHeader>
                  <TableRow className="bg-emerald-100">
                    <TableHead className="border font-semibold text-center" colSpan={3}>PENDUDUK</TableHead>
                  </TableRow>
                  <TableRow className="bg-emerald-50">
                    <TableHead className="border text-center font-medium">LAKI-LAKI</TableHead>
                    <TableHead className="border text-center font-medium">PEREMPUAN</TableHead>
                    <TableHead className="border text-center font-medium">JUMLAH</TableHead>
                  </TableRow>
                </TableHeader>
                <TableBody>
                  <TableRow>
                    <TableCell className="border text-center">{statistik?.penduduk.lakiLaki || 0}</TableCell>
                    <TableCell className="border text-center">{statistik?.penduduk.perempuan || 0}</TableCell>
                    <TableCell className="border text-center font-semibold">{statistik?.penduduk.total || 0}</TableCell>
                  </TableRow>
                </TableBody>
              </Table>

              {/* Wajib KTP (17 Tahun) */}
              <Table className="border text-xs md:text-sm">
                <TableHeader>
                  <TableRow className="bg-blue-100">
                    <TableHead className="border font-semibold text-center" colSpan={3}>WAJIB KTP (17 TAHUN)</TableHead>
                  </TableRow>
                  <TableRow className="bg-blue-50">
                    <TableHead className="border text-center font-medium">LAKI-LAKI</TableHead>
                    <TableHead className="border text-center font-medium">PEREMPUAN</TableHead>
                    <TableHead className="border text-center font-medium">JUMLAH</TableHead>
                  </TableRow>
                </TableHeader>
                <TableBody>
                  <TableRow>
                    <TableCell className="border text-center">{statistik?.wajibKTP.lakiLaki || 0}</TableCell>
                    <TableCell className="border text-center">{statistik?.wajibKTP.perempuan || 0}</TableCell>
                    <TableCell className="border text-center font-semibold">{statistik?.wajibKTP.total || 0}</TableCell>
                  </TableRow>
                </TableBody>
              </Table>

              {/* Kartu Keluarga */}
              <Table className="border text-xs md:text-sm">
                <TableHeader>
                  <TableRow className="bg-purple-100">
                    <TableHead className="border font-semibold text-center" colSpan={3}>KARTU KELUARGA</TableHead>
                  </TableRow>
                  <TableRow className="bg-purple-50">
                    <TableHead className="border text-center font-medium">LAKI-LAKI</TableHead>
                    <TableHead className="border text-center font-medium">PEREMPUAN</TableHead>
                    <TableHead className="border text-center font-medium">JUMLAH</TableHead>
                  </TableRow>
                </TableHeader>
                <TableBody>
                  <TableRow>
                    <TableCell className="border text-center">{statistik?.kartuKeluarga.lakiLaki || 0}</TableCell>
                    <TableCell className="border text-center">{statistik?.kartuKeluarga.perempuan || 0}</TableCell>
                    <TableCell className="border text-center font-semibold">{statistik?.kartuKeluarga.total || 0}</TableCell>
                  </TableRow>
                </TableBody>
              </Table>

              {/* Penduduk Sementara */}
              <Table className="border text-xs md:text-sm">
                <TableHeader>
                  <TableRow className="bg-orange-100">
                    <TableHead className="border font-semibold text-center" colSpan={3}>PENDUDUK SEMENTARA</TableHead>
                  </TableRow>
                  <TableRow className="bg-orange-50">
                    <TableHead className="border text-center font-medium">LAKI-LAKI</TableHead>
                    <TableHead className="border text-center font-medium">PEREMPUAN</TableHead>
                    <TableHead className="border text-center font-medium">JUMLAH</TableHead>
                  </TableRow>
                </TableHeader>
                <TableBody>
                  <TableRow>
                    <TableCell className="border text-center">{statistik?.pendudukSementara.lakiLaki || 0}</TableCell>
                    <TableCell className="border text-center">{statistik?.pendudukSementara.perempuan || 0}</TableCell>
                    <TableCell className="border text-center font-semibold">{(statistik?.pendudukSementara.lakiLaki || 0) + (statistik?.pendudukSementara.perempuan || 0)}</TableCell>
                  </TableRow>
                </TableBody>
              </Table>

              {/* Kejadian Tables */}
              <div className="grid grid-cols-2 gap-2">
                {/* Lahir */}
                <Table className="border text-xs">
                  <TableHeader>
                    <TableRow className="bg-green-100">
                      <TableHead className="border font-semibold text-center" colSpan={2}>LAHIR</TableHead>
                    </TableRow>
                    <TableRow className="bg-green-50">
                      <TableHead className="border text-center font-medium">L</TableHead>
                      <TableHead className="border text-center font-medium">P</TableHead>
                    </TableRow>
                  </TableHeader>
                  <TableBody>
                    <TableRow>
                      <TableCell className="border text-center">{statistik?.kejadian.lahir.l || 0}</TableCell>
                      <TableCell className="border text-center">{statistik?.kejadian.lahir.p || 0}</TableCell>
                    </TableRow>
                  </TableBody>
                </Table>

                {/* Meninggal */}
                <Table className="border text-xs">
                  <TableHeader>
                    <TableRow className="bg-gray-200">
                      <TableHead className="border font-semibold text-center" colSpan={2}>MENINGGAL</TableHead>
                    </TableRow>
                    <TableRow className="bg-gray-100">
                      <TableHead className="border text-center font-medium">L</TableHead>
                      <TableHead className="border text-center font-medium">P</TableHead>
                    </TableRow>
                  </TableHeader>
                  <TableBody>
                    <TableRow>
                      <TableCell className="border text-center">{statistik?.kejadian.meninggal.l || 0}</TableCell>
                      <TableCell className="border text-center">{statistik?.kejadian.meninggal.p || 0}</TableCell>
                    </TableRow>
                  </TableBody>
                </Table>

                {/* Pindah */}
                <Table className="border text-xs">
                  <TableHeader>
                    <TableRow className="bg-yellow-100">
                      <TableHead className="border font-semibold text-center" colSpan={2}>PINDAH</TableHead>
                    </TableRow>
                    <TableRow className="bg-yellow-50">
                      <TableHead className="border text-center font-medium">L</TableHead>
                      <TableHead className="border text-center font-medium">P</TableHead>
                    </TableRow>
                  </TableHeader>
                  <TableBody>
                    <TableRow>
                      <TableCell className="border text-center">{statistik?.kejadian.pindah.l || 0}</TableCell>
                      <TableCell className="border text-center">{statistik?.kejadian.pindah.p || 0}</TableCell>
                    </TableRow>
                  </TableBody>
                </Table>

                {/* Datang */}
                <Table className="border text-xs">
                  <TableHeader>
                    <TableRow className="bg-blue-100">
                      <TableHead className="border font-semibold text-center" colSpan={2}>DATANG</TableHead>
                    </TableRow>
                    <TableRow className="bg-blue-50">
                      <TableHead className="border text-center font-medium">L</TableHead>
                      <TableHead className="border text-center font-medium">P</TableHead>
                    </TableRow>
                  </TableHeader>
                  <TableBody>
                    <TableRow>
                      <TableCell className="border text-center">{statistik?.kejadian.datang.l || 0}</TableCell>
                      <TableCell className="border text-center">{statistik?.kejadian.datang.p || 0}</TableCell>
                    </TableRow>
                  </TableBody>
                </Table>
              </div>
            </div>
          </div>

          {/* Keterangan Perubahan Penduduk */}
          <div className="mt-6">
            <Table className="border text-xs md:text-sm">
              <TableHeader>
                <TableRow className="bg-amber-100">
                  <TableHead className="border font-semibold text-center">
                    KETERANGAN PERUBAHAN PENDUDUK
                  </TableHead>
                </TableRow>
              </TableHeader>
              <TableBody>
                <TableRow>
                  <TableCell className="border p-2">
                    {/* Input mode (visible on screen, hidden on print) */}
                    <Textarea
                      value={keteranganPerubahan}
                      onChange={(e) => setKeteranganPerubahan(e.target.value)}
                      placeholder="Tulis keterangan perubahan penduduk di sini... (misal: Lahir 1 orang, Pindah 2 orang, dll)"
                      className="min-h-[80px] resize-none text-sm no-print"
                      rows={3}
                    />
                    {/* Print mode (hidden on screen, visible on print) */}
                    <div className="print-only min-h-[60px] whitespace-pre-wrap text-sm">
                      {keteranganPerubahan || '-'}
                    </div>
                  </TableCell>
                </TableRow>
              </TableBody>
            </Table>
          </div>

          {/* Realisasi Pembuatan KTP dan KK Bulan Ini */}
          <div className="mt-4">
            <Table className="border text-xs md:text-sm">
              <TableHeader>
                <TableRow className="bg-teal-100">
                  <TableHead className="border font-semibold text-center">
                    REALISASI PEMBUATAN KTP DAN KK BULAN INI
                  </TableHead>
                </TableRow>
              </TableHeader>
              <TableBody>
                <TableRow>
                  <TableCell className="border p-2">
                    {/* Input mode (visible on screen, hidden on print) */}
                    <Textarea
                      value={realisasiKTPKK}
                      onChange={(e) => setRealisasiKTPKK(e.target.value)}
                      placeholder="Tulis realisasi pembuatan KTP dan KK bulan ini... (misal: Pembuatan KTP baru: 3 orang, Perpanjangan KK: 2 KK)"
                      className="min-h-[80px] resize-none text-sm no-print"
                      rows={3}
                    />
                    {/* Print mode (hidden on screen, visible on print) */}
                    <div className="print-only min-h-[60px] whitespace-pre-wrap text-sm">
                      {realisasiKTPKK || '-'}
                    </div>
                  </TableCell>
                </TableRow>
              </TableBody>
            </Table>
          </div>

          {/* Signature */}
          <div className="mt-8 flex justify-end">
            <div className="text-center">
              <p className="text-sm">Sukamaju, {selectedDate.tanggal} {selectedDate.bulan} {selectedDate.tahun}</p>
              <p className="text-sm">Ketua RT. {settings?.rt || '001'}</p>
              <div className="h-20"></div>
              <p className="text-sm font-semibold underline">{settings?.ketuaRT || 'Herman Gozali'}</p>
            </div>
          </div>
        </CardContent>
      </Card>

      {/* Print Styles */}
      <style jsx global>{`
        @media print {
          .print-area {
            box-shadow: none !important;
            border: none !important;
          }
        }
      `}</style>
    </div>
  )
}
