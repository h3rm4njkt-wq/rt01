'use client'

import { useState, useEffect } from 'react'
import { Button } from '@/components/ui/button'
import { Card, CardContent } from '@/components/ui/card'
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from '@/components/ui/table'
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
  DialogFooter,
} from '@/components/ui/dialog'
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from '@/components/ui/select'
import { Input } from '@/components/ui/input'
import { Label } from '@/components/ui/label'
import { Badge } from '@/components/ui/badge'
import {
  Plus,
  Edit,
  Trash2,
  Download,
  Search,
  Eye,
  UserPlus,
  X,
} from 'lucide-react'
import { useToast } from '@/hooks/use-toast'

interface Penduduk {
  id: string
  nik: string
  nama: string
  jenisKelamin: string
  tempatLahir: string
  tanggalLahir: string | null
  agama: string
  pendidikan: string
  pekerjaan: string
  statusPerkawinan: string
  kewarganegaraan: string
  statusWarga: string
  namaAyah: string
  namaIbu: string
  namaPanggilan: string
  bpjs: string
  noKKId: string | null
  isKepalaKeluarga: boolean
  kartuKeluarga?: {
    noKK: string
    namaKepalaKeluarga: string
  }
}

interface KartuKeluargaOption {
  id: string
  noKK: string
  namaKepalaKeluarga: string
}

const JENIS_KELAMIN_OPTIONS = ['Laki-Laki', 'Perempuan']
const AGAMA_OPTIONS = ['ISLAM', 'KRISTEN', 'KATOLIK', 'HINDU', 'BUDDHA', 'KONGHUCU']
const PENDIDIKAN_OPTIONS = [
  'TIDAK/BELUM SEKOLAH',
  'BELUM TAMAT SD/SEDERAJAT',
  'TIDAK TAMAT SD/SEDERAJAT',
  'SD/SEDERAJAT',
  'SMP/SEDERAJAT',
  'SMA/SEDERAJAT',
  'PAKET A',
  'PAKET B',
  'PAKET C',
  'SLB',
  'D1',
  'D2',
  'D3',
  'S1',
  'S2',
  'S3',
]
const PEKERJAAN_OPTIONS = [
  'PELAJAR/MAHASISWA',
  'PNS',
  'SOPIR',
  'USTADZ/MUBALIGH',
  'PEDAGANG',
  'BELUM/TIDAKBEKERJA',
  'BURUH HARIAN LEPAS',
  'MENGURUS RUMAH TANGGA',
  'WIRASWASTA',
  'PEGAWAI ASN',
  'KARYAWAN SWASTA',
  'TNI',
  'POLRI',
]
const STATUS_PERKAWINAN_OPTIONS = ['BELUM MENIKAH', 'KAWIN', 'CERAI HIDUP', 'CERAI MATI']
const STATUS_WARGA_OPTIONS = ['TETAP', 'KONTRAK', 'SEWA', 'MENUMPANG', 'KOS']
const BPJS_OPTIONS = ['Tidak', 'Mandiri', 'PBI']

export function PendudukTab() {
  const [data, setData] = useState<Penduduk[]>([])
  const [kkOptions, setKkOptions] = useState<KartuKeluargaOption[]>([])
  const [loading, setLoading] = useState(true)
  const [searchTerm, setSearchTerm] = useState('')
  const [dialogOpen, setDialogOpen] = useState(false)
  const [detailOpen, setDetailOpen] = useState(false)
  const [editMode, setEditMode] = useState(false)
  const [selectedPenduduk, setSelectedPenduduk] = useState<Penduduk | null>(null)
  const [formData, setFormData] = useState({
    nik: '',
    nama: '',
    jenisKelamin: 'Laki-Laki',
    tempatLahir: '',
    tanggalLahir: '',
    agama: 'ISLAM',
    pendidikan: '',
    pekerjaan: '',
    statusPerkawinan: 'BELUM MENIKAH',
    kewarganegaraan: 'WNI',
    statusWarga: 'TETAP',
    namaAyah: '',
    namaIbu: '',
    namaPanggilan: '',
    bpjs: 'Tidak',
    noKKId: '',
    isKepalaKeluarga: false,
  })
  const [anggotaKeluarga, setAnggotaKeluarga] = useState<Array<{
    nik: string
    nama: string
    jenisKelamin: string
    tempatLahir: string
    tanggalLahir: string
    namaAyah: string
    namaIbu: string
    namaPanggilan: string
    bpjs: string
  }>>([])
  const { toast } = useToast()

  useEffect(() => {
    fetchData()
    fetchKKOptions()
  }, [])

  const fetchData = async () => {
    try {
      const res = await fetch('/api/penduduk')
      const result = await res.json()
      setData(result)
    } catch (error) {
      console.error('Error fetching data:', error)
    } finally {
      setLoading(false)
    }
  }

  const fetchKKOptions = async () => {
    try {
      const res = await fetch('/api/kartu-keluarga')
      const result = await res.json()
      setKkOptions(result)
    } catch (error) {
      console.error('Error fetching KK options:', error)
    }
  }

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault()
    
    // Validasi NIK harus 16 digit
    if (!/^[0-9]{16}$/.test(formData.nik)) {
      toast({ title: 'Error', description: 'NIK harus 16 digit angka', variant: 'destructive' })
      return
    }
    
    // Validasi NIK anggota keluarga baru jika ada
    for (const anggota of anggotaKeluarga) {
      if (anggota.nik && !/^[0-9]{16}$/.test(anggota.nik)) {
        toast({ title: 'Error', description: `NIK ${anggota.nama || 'anggota'} harus 16 digit angka`, variant: 'destructive' })
        return
      }
    }
    
    try {
      const payload = {
        ...formData,
        tanggalLahir: formData.tanggalLahir || null,
        noKKId: formData.noKKId || null,
      }

      if (editMode && selectedPenduduk) {
        // Include anggota keluarga baru jika ada
        if (anggotaKeluarga.length > 0) {
          payload.anggotaBaru = anggotaKeluarga.filter(a => a.nik && a.nama)
        }
        const res = await fetch(`/api/penduduk/${selectedPenduduk.id}`, {
          method: 'PUT',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify(payload),
        })
        if (!res.ok) {
          const error = await res.json()
          throw new Error(error.error || 'Gagal mengupdate data')
        }
        toast({ title: 'Berhasil', description: anggotaKeluarga.length > 0 ? 'Data penduduk diupdate & anggota keluarga ditambahkan' : 'Data penduduk diupdate' })
      } else {
        const res = await fetch('/api/penduduk', {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify(payload),
        })
        if (!res.ok) {
          const error = await res.json()
          throw new Error(error.error || 'Gagal menambah data')
        }
        toast({ title: 'Berhasil', description: 'Penduduk ditambahkan' })
      }

      setDialogOpen(false)
      resetForm()
      fetchData()
    } catch (error) {
      toast({
        title: 'Error',
        description: (error as Error).message,
        variant: 'destructive',
      })
    }
  }

  const handleDelete = async (id: string) => {
    if (!confirm('Yakin ingin menghapus penduduk ini?')) return
    try {
      const res = await fetch(`/api/penduduk/${id}`, { method: 'DELETE' })
      if (!res.ok) throw new Error('Gagal menghapus')
      toast({ title: 'Berhasil', description: 'Penduduk dihapus' })
      fetchData()
    } catch (error) {
      toast({
        title: 'Error',
        description: (error as Error).message,
        variant: 'destructive',
      })
    }
  }

  const handleViewDetail = (penduduk: Penduduk) => {
    setSelectedPenduduk(penduduk)
    setDetailOpen(true)
  }

  const handleEdit = (penduduk: Penduduk) => {
    setEditMode(true)
    setSelectedPenduduk(penduduk)
    setFormData({
      nik: penduduk.nik,
      nama: penduduk.nama,
      jenisKelamin: penduduk.jenisKelamin,
      tempatLahir: penduduk.tempatLahir || '',
      tanggalLahir: penduduk.tanggalLahir ? penduduk.tanggalLahir.split('T')[0] : '',
      agama: penduduk.agama || 'ISLAM',
      pendidikan: penduduk.pendidikan || '',
      pekerjaan: penduduk.pekerjaan || '',
      statusPerkawinan: penduduk.statusPerkawinan || 'BELUM MENIKAH',
      kewarganegaraan: penduduk.kewarganegaraan || 'WNI',
      statusWarga: penduduk.statusWarga || 'TETAP',
      namaAyah: penduduk.namaAyah || '',
      namaIbu: penduduk.namaIbu || '',
      namaPanggilan: penduduk.namaPanggilan || '',
      bpjs: penduduk.bpjs || 'Tidak',
      noKKId: penduduk.noKKId || '',
      isKepalaKeluarga: penduduk.isKepalaKeluarga,
    })
    setDialogOpen(true)
  }

  const resetForm = () => {
    setFormData({
      nik: '',
      nama: '',
      jenisKelamin: 'Laki-Laki',
      tempatLahir: '',
      tanggalLahir: '',
      agama: 'ISLAM',
      pendidikan: '',
      pekerjaan: '',
      statusPerkawinan: 'BELUM MENIKAH',
      kewarganegaraan: 'WNI',
      statusWarga: 'TETAP',
      namaAyah: '',
      namaIbu: '',
      namaPanggilan: '',
      bpjs: 'Tidak',
      noKKId: '',
      isKepalaKeluarga: false,
    })
    setAnggotaKeluarga([])
    setEditMode(false)
    setSelectedPenduduk(null)
  }

  const addAnggotaKeluarga = () => {
    setAnggotaKeluarga([
      ...anggotaKeluarga,
      {
        nik: '',
        nama: '',
        jenisKelamin: 'Laki-Laki',
        tempatLahir: '',
        tanggalLahir: '',
        namaAyah: '',
        namaIbu: '',
        namaPanggilan: '',
        bpjs: 'Tidak',
      },
    ])
  }

  const removeAnggotaKeluarga = (index: number) => {
    setAnggotaKeluarga(anggotaKeluarga.filter((_, i) => i !== index))
  }

  const updateAnggotaKeluarga = (index: number, field: string, value: string) => {
    const updated = [...anggotaKeluarga]
    updated[index] = { ...updated[index], [field]: value }
    setAnggotaKeluarga(updated)
  }

  const handleExport = () => {
    window.open('/api/export?type=penduduk', '_blank')
  }

  const formatDate = (date: string | null) => {
    if (!date) return '-'
    const d = new Date(date)
    return `${d.getDate().toString().padStart(2, '0')}/${(d.getMonth() + 1).toString().padStart(2, '0')}/${d.getFullYear()}}`
  }

  const filteredData = data.filter(
    (p) =>
      p.nik.toLowerCase().includes(searchTerm.toLowerCase()) ||
      p.nama.toLowerCase().includes(searchTerm.toLowerCase())
  )

  if (loading) {
    return (
      <div className="flex items-center justify-center h-64">
        <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-emerald-600"></div>
      </div>
    )
  }

  return (
    <div className="space-y-4">
      {/* Action Buttons */}
      <div className="flex flex-wrap gap-2">
        <Button onClick={() => { resetForm(); setDialogOpen(true) }} className="bg-emerald-600 hover:bg-emerald-700">
          <Plus className="h-4 w-4 mr-2" />
          Tambah Penduduk
        </Button>
        <Button variant="outline" onClick={handleExport}>
          <Download className="h-4 w-4 mr-2" />
          Export
        </Button>
      </div>

      {/* Search */}
      <div className="relative">
        <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 h-4 w-4 text-gray-400" />
        <Input
          placeholder="Cari NIK atau Nama..."
          value={searchTerm}
          onChange={(e) => setSearchTerm(e.target.value)}
          className="pl-10"
        />
      </div>

      {/* Table */}
      <Card>
        <CardContent className="p-0">
          <div className="overflow-x-auto">
            <Table>
              <TableHeader>
                <TableRow>
                  <TableHead>No Kartu Keluarga</TableHead>
                  <TableHead>NIK</TableHead>
                  <TableHead>Nama</TableHead>
                  <TableHead>Nama Panggilan</TableHead>
                  <TableHead>Jenis Kelamin</TableHead>
                  <TableHead>TTL</TableHead>
                  <TableHead>BPJS</TableHead>
                  <TableHead>Status</TableHead>
                  <TableHead className="w-28">Aksi</TableHead>
                </TableRow>
              </TableHeader>
              <TableBody>
                {filteredData.length === 0 ? (
                  <TableRow>
                    <TableCell colSpan={9} className="text-center py-8 text-gray-500">
                      Tidak ada data
                    </TableCell>
                  </TableRow>
                ) : (
                  filteredData.map((p, index) => {
                    const showKK = p.isKepalaKeluarga && p.kartuKeluarga
                    const isNewKK = index === 0 || (filteredData[index - 1]?.noKKId !== p.noKKId)
                    return (
                      <TableRow key={p.id} className={isNewKK && p.isKepalaKeluarga ? 'border-t-2 border-emerald-200 bg-emerald-50/30' : ''}>
                        <TableCell className="font-mono text-xs">
                          {showKK && p.kartuKeluarga ? (
                            <span className="font-semibold text-emerald-700">{p.kartuKeluarga.noKK}</span>
                          ) : (
                            <span className="text-gray-400">-</span>
                          )}
                        </TableCell>
                        <TableCell className="font-mono text-xs">{p.nik}</TableCell>
                        <TableCell className="font-medium">
                          {p.nama}
                          {p.isKepalaKeluarga && (
                            <Badge variant="outline" className="ml-2 text-xs bg-emerald-100 text-emerald-800 border-emerald-300">KK</Badge>
                          )}
                        </TableCell>
                        <TableCell className="text-xs text-gray-600">{p.namaPanggilan || '-'}</TableCell>
                        <TableCell>{p.jenisKelamin === 'Laki-Laki' ? 'L' : 'P'}</TableCell>
                      <TableCell className="text-xs">
                        {p.tempatLahir}, {formatDate(p.tanggalLahir)}
                      </TableCell>
                      <TableCell>
                        <Badge variant={p.bpjs === 'Tidak' ? 'outline' : 'default'} className="text-xs">
                          {p.bpjs}
                        </Badge>
                      </TableCell>
                      <TableCell>
                        <Badge variant={p.statusWarga === 'TETAP' ? 'default' : 'secondary'} className="text-xs">
                          {p.statusWarga}
                        </Badge>
                      </TableCell>
                      <TableCell>
                        <div className="flex gap-1">
                          <Button
                            variant="ghost"
                            size="sm"
                            onClick={() => handleViewDetail(p)}
                            title="Detail"
                          >
                            <Eye className="h-4 w-4" />
                          </Button>
                          <Button
                            variant="ghost"
                            size="sm"
                            onClick={() => handleEdit(p)}
                            title="Edit"
                          >
                            <Edit className="h-4 w-4" />
                          </Button>
                          <Button
                            variant="ghost"
                            size="sm"
                            onClick={() => handleDelete(p.id)}
                            title="Hapus"
                          >
                            <Trash2 className="h-4 w-4 text-red-500" />
                          </Button>
                        </div>
                      </TableCell>
                    </TableRow>
                  )})
                )}
              </TableBody>
            </Table>
          </div>
        </CardContent>
      </Card>

      {/* Dialog Tambah/Edit Penduduk */}
      <Dialog open={dialogOpen} onOpenChange={setDialogOpen}>
        <DialogContent className="max-w-2xl max-h-[90vh] overflow-hidden flex flex-col">
          <DialogHeader>
            <DialogTitle>{editMode ? 'Edit Penduduk' : 'Tambah Penduduk Baru'}</DialogTitle>
          </DialogHeader>
          <form onSubmit={handleSubmit} className="flex flex-col flex-1 overflow-hidden">
            <div className="flex-1 overflow-y-auto pr-2 -mr-2">
              <div className="space-y-4">
                <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                  <div>
                    <Label htmlFor="nik">NIK * (16 digit)</Label>
                    <Input
                      id="nik"
                      value={formData.nik}
                      onChange={(e) => setFormData({ ...formData, nik: e.target.value.replace(/\D/g, '').slice(0, 16) })}
                      required
                      maxLength={16}
                    />
                    {formData.nik.length > 0 && formData.nik.length !== 16 && (
                      <p className="text-xs text-red-500 mt-1">NIK harus 16 digit ({formData.nik.length}/16)</p>
                    )}
                  </div>
                  <div>
                    <Label htmlFor="nama">Nama Lengkap *</Label>
                    <Input
                      id="nama"
                      value={formData.nama}
                      onChange={(e) => setFormData({ ...formData, nama: e.target.value })}
                      required
                    />
                  </div>
                </div>

                <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                  <div>
                    <Label htmlFor="jenisKelamin">Jenis Kelamin</Label>
                    <Select
                      value={formData.jenisKelamin}
                      onValueChange={(v) => setFormData({ ...formData, jenisKelamin: v })}
                    >
                      <SelectTrigger>
                        <SelectValue placeholder="Pilih jenis kelamin" />
                      </SelectTrigger>
                      <SelectContent>
                        {JENIS_KELAMIN_OPTIONS.map((opt) => (
                          <SelectItem key={opt} value={opt}>{opt}</SelectItem>
                        ))}
                      </SelectContent>
                    </Select>
                  </div>
                  <div>
                    <Label htmlFor="tempatLahir">Tempat Lahir</Label>
                    <Input
                      id="tempatLahir"
                      value={formData.tempatLahir}
                      onChange={(e) => setFormData({ ...formData, tempatLahir: e.target.value })}
                    />
                  </div>
                </div>

                <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                  <div>
                    <Label htmlFor="tanggalLahir">Tanggal Lahir</Label>
                    <Input
                      id="tanggalLahir"
                      type="date"
                      value={formData.tanggalLahir}
                      onChange={(e) => setFormData({ ...formData, tanggalLahir: e.target.value })}
                    />
                  </div>
                  <div>
                    <Label htmlFor="agama">Agama</Label>
                    <Select
                      value={formData.agama}
                      onValueChange={(v) => setFormData({ ...formData, agama: v })}
                    >
                      <SelectTrigger>
                        <SelectValue placeholder="Pilih agama" />
                      </SelectTrigger>
                      <SelectContent>
                        {AGAMA_OPTIONS.map((opt) => (
                          <SelectItem key={opt} value={opt}>{opt}</SelectItem>
                        ))}
                      </SelectContent>
                    </Select>
                  </div>
                </div>

                <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                  <div>
                    <Label htmlFor="pendidikan">Pendidikan Terakhir</Label>
                    <Select
                      value={formData.pendidikan}
                      onValueChange={(v) => setFormData({ ...formData, pendidikan: v })}
                    >
                      <SelectTrigger>
                        <SelectValue placeholder="Pilih pendidikan" />
                      </SelectTrigger>
                      <SelectContent>
                        {PENDIDIKAN_OPTIONS.map((opt) => (
                          <SelectItem key={opt} value={opt}>{opt}</SelectItem>
                        ))}
                      </SelectContent>
                    </Select>
                  </div>
                  <div>
                    <Label htmlFor="pekerjaan">Pekerjaan</Label>
                    <Select
                      value={formData.pekerjaan}
                      onValueChange={(v) => setFormData({ ...formData, pekerjaan: v })}
                    >
                      <SelectTrigger>
                        <SelectValue placeholder="Pilih pekerjaan" />
                      </SelectTrigger>
                      <SelectContent>
                        {PEKERJAAN_OPTIONS.map((opt) => (
                          <SelectItem key={opt} value={opt}>{opt}</SelectItem>
                        ))}
                      </SelectContent>
                    </Select>
                  </div>
                </div>

                <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                  <div>
                    <Label htmlFor="statusPerkawinan">Status Perkawinan</Label>
                    <Select
                      value={formData.statusPerkawinan}
                      onValueChange={(v) => setFormData({ ...formData, statusPerkawinan: v })}
                    >
                      <SelectTrigger>
                        <SelectValue placeholder="Pilih status" />
                      </SelectTrigger>
                      <SelectContent>
                        {STATUS_PERKAWINAN_OPTIONS.map((opt) => (
                          <SelectItem key={opt} value={opt}>{opt}</SelectItem>
                        ))}
                      </SelectContent>
                    </Select>
                  </div>
                  <div>
                    <Label htmlFor="statusWarga">Status Warga</Label>
                    <Select
                      value={formData.statusWarga}
                      onValueChange={(v) => setFormData({ ...formData, statusWarga: v })}
                    >
                      <SelectTrigger>
                        <SelectValue placeholder="Pilih status" />
                      </SelectTrigger>
                      <SelectContent>
                        {STATUS_WARGA_OPTIONS.map((opt) => (
                          <SelectItem key={opt} value={opt}>{opt}</SelectItem>
                        ))}
                      </SelectContent>
                    </Select>
                  </div>
                </div>

                <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                  <div>
                    <Label htmlFor="bpjs">BPJS</Label>
                    <Select
                      value={formData.bpjs}
                      onValueChange={(v) => setFormData({ ...formData, bpjs: v })}
                    >
                      <SelectTrigger>
                        <SelectValue placeholder="Pilih BPJS" />
                      </SelectTrigger>
                      <SelectContent>
                        {BPJS_OPTIONS.map((opt) => (
                          <SelectItem key={opt} value={opt}>{opt}</SelectItem>
                        ))}
                      </SelectContent>
                    </Select>
                  </div>
                  <div>
                    <Label htmlFor="noKKId">No KK</Label>
                    <Select
                      value={formData.noKKId}
                      onValueChange={(v) => setFormData({ ...formData, noKKId: v })}
                    >
                      <SelectTrigger>
                        <SelectValue placeholder="Pilih No KK" />
                      </SelectTrigger>
                      <SelectContent>
                        {kkOptions.map((kk) => (
                          <SelectItem key={kk.id} value={kk.id}>
                            {kk.noKK} - {kk.namaKepalaKeluarga}
                          </SelectItem>
                        ))}
                      </SelectContent>
                    </Select>
                  </div>
                </div>

                <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                  <div>
                    <Label htmlFor="namaAyah">Nama Ayah</Label>
                    <Input
                      id="namaAyah"
                      value={formData.namaAyah}
                      onChange={(e) => setFormData({ ...formData, namaAyah: e.target.value })}
                    />
                  </div>
                  <div>
                    <Label htmlFor="namaIbu">Nama Ibu</Label>
                    <Input
                      id="namaIbu"
                      value={formData.namaIbu}
                      onChange={(e) => setFormData({ ...formData, namaIbu: e.target.value })}
                    />
                  </div>
                </div>

                <div>
                  <Label htmlFor="namaPanggilan">Nama Panggilan</Label>
                  <Input
                    id="namaPanggilan"
                    value={formData.namaPanggilan}
                    onChange={(e) => setFormData({ ...formData, namaPanggilan: e.target.value })}
                  />
                </div>

                {/* Tambahan Anggota Keluarga - hanya di mode edit */}
                {editMode && formData.noKKId && (
                  <div className="border-t pt-4">
                    <div className="flex items-center justify-between mb-3">
                      <Label className="font-semibold text-emerald-700">Tambah Anggota Keluarga</Label>
                      <Button
                        type="button"
                        variant="outline"
                        size="sm"
                        onClick={addAnggotaKeluarga}
                        className="text-emerald-600 border-emerald-600"
                      >
                        <UserPlus className="h-4 w-4 mr-1" />
                        Tambah Anggota
                      </Button>
                    </div>
                    
                    {anggotaKeluarga.length > 0 && (
                      <div className="space-y-3">
                        {anggotaKeluarga.map((anggota, index) => (
                          <div key={index} className="border rounded-lg p-3 bg-gray-50">
                            <div className="flex items-center justify-between mb-2">
                              <span className="text-sm font-medium text-gray-600">Anggota {index + 1}</span>
                              <Button
                                type="button"
                                variant="ghost"
                                size="sm"
                                onClick={() => removeAnggotaKeluarga(index)}
                              >
                                <X className="h-4 w-4 text-red-500" />
                              </Button>
                            </div>
                            <div className="grid grid-cols-1 md:grid-cols-2 gap-2">
                              <div>
                                <Input
                                  placeholder="NIK (16 digit)"
                                  value={anggota.nik}
                                  onChange={(e) => updateAnggotaKeluarga(index, 'nik', e.target.value.replace(/\D/g, '').slice(0, 16))}
                                  maxLength={16}
                                />
                                {anggota.nik.length > 0 && anggota.nik.length !== 16 && (
                                  <p className="text-xs text-red-500 mt-1">NIK harus 16 digit</p>
                                )}
                              </div>
                              <Input
                                placeholder="Nama Lengkap"
                                value={anggota.nama}
                                onChange={(e) => updateAnggotaKeluarga(index, 'nama', e.target.value)}
                              />
                              <Select
                                value={anggota.jenisKelamin}
                                onValueChange={(v) => updateAnggotaKeluarga(index, 'jenisKelamin', v)}
                              >
                                <SelectTrigger>
                                  <SelectValue placeholder="Jenis Kelamin" />
                                </SelectTrigger>
                                <SelectContent>
                                  <SelectItem value="Laki-Laki">Laki-Laki</SelectItem>
                                  <SelectItem value="Perempuan">Perempuan</SelectItem>
                                </SelectContent>
                              </Select>
                              <Input
                                placeholder="Tempat Lahir"
                                value={anggota.tempatLahir}
                                onChange={(e) => updateAnggotaKeluarga(index, 'tempatLahir', e.target.value)}
                              />
                              <Input
                                type="date"
                                value={anggota.tanggalLahir}
                                onChange={(e) => updateAnggotaKeluarga(index, 'tanggalLahir', e.target.value)}
                              />
                              <Input
                                placeholder="Nama Panggilan"
                                value={anggota.namaPanggilan}
                                onChange={(e) => updateAnggotaKeluarga(index, 'namaPanggilan', e.target.value)}
                              />
                              <Input
                                placeholder="Nama Ayah"
                                value={anggota.namaAyah}
                                onChange={(e) => updateAnggotaKeluarga(index, 'namaAyah', e.target.value)}
                              />
                              <Input
                                placeholder="Nama Ibu"
                                value={anggota.namaIbu}
                                onChange={(e) => updateAnggotaKeluarga(index, 'namaIbu', e.target.value)}
                              />
                              <Select
                                value={anggota.bpjs}
                                onValueChange={(v) => updateAnggotaKeluarga(index, 'bpjs', v)}
                              >
                                <SelectTrigger>
                                  <SelectValue placeholder="BPJS" />
                                </SelectTrigger>
                                <SelectContent>
                                  {BPJS_OPTIONS.map((opt) => (
                                    <SelectItem key={opt} value={opt}>{opt}</SelectItem>
                                  ))}
                                </SelectContent>
                              </Select>
                            </div>
                          </div>
                        ))}
                      </div>
                    )}
                  </div>
                )}
              </div>
            </div>
            <DialogFooter className="mt-4 pt-4 border-t flex-shrink-0">
              <Button type="button" variant="outline" onClick={() => setDialogOpen(false)}>
                Batal
              </Button>
              <Button type="submit" className="bg-emerald-600 hover:bg-emerald-700">
                {editMode ? 'Update' : 'Simpan'}
              </Button>
            </DialogFooter>
          </form>
        </DialogContent>
      </Dialog>

      {/* Dialog Detail Penduduk */}
      <Dialog open={detailOpen} onOpenChange={setDetailOpen}>
        <DialogContent className="max-w-2xl max-h-[90vh] overflow-hidden flex flex-col">
          <DialogHeader>
            <DialogTitle>Detail Penduduk</DialogTitle>
          </DialogHeader>
          {selectedPenduduk && (
            <div className="flex-1 overflow-y-auto pr-2 -mr-2">
              <div className="space-y-4">
                <div className="grid grid-cols-2 gap-4 text-sm">
                  <div>
                    <span className="text-gray-500">No KK:</span>
                    <p className="font-mono font-semibold">
                      {selectedPenduduk.isKepalaKeluarga && selectedPenduduk.kartuKeluarga 
                        ? selectedPenduduk.kartuKeluarga.noKK 
                        : '-'}
                    </p>
                  </div>
                  <div>
                    <span className="text-gray-500">NIK:</span>
                    <p className="font-mono font-semibold">{selectedPenduduk.nik}</p>
                  </div>
                  <div>
                    <span className="text-gray-500">Nama Lengkap:</span>
                    <p className="font-semibold">{selectedPenduduk.nama}</p>
                  </div>
                  <div>
                    <span className="text-gray-500">Nama Panggilan:</span>
                    <p>{selectedPenduduk.namaPanggilan || '-'}</p>
                  </div>
                  <div>
                    <span className="text-gray-500">Jenis Kelamin:</span>
                    <p>{selectedPenduduk.jenisKelamin}</p>
                  </div>
                  <div>
                    <span className="text-gray-500">Tempat, Tanggal Lahir:</span>
                    <p>{selectedPenduduk.tempatLahir}, {formatDate(selectedPenduduk.tanggalLahir)}</p>
                  </div>
                  <div>
                    <span className="text-gray-500">Agama:</span>
                    <p>{selectedPenduduk.agama || '-'}</p>
                  </div>
                  <div>
                    <span className="text-gray-500">Pendidikan:</span>
                    <p>{selectedPenduduk.pendidikan || '-'}</p>
                  </div>
                  <div>
                    <span className="text-gray-500">Pekerjaan:</span>
                    <p>{selectedPenduduk.pekerjaan || '-'}</p>
                  </div>
                  <div>
                    <span className="text-gray-500">Status Perkawinan:</span>
                    <p>{selectedPenduduk.statusPerkawinan || '-'}</p>
                  </div>
                  <div>
                    <span className="text-gray-500">Kewarganegaraan:</span>
                    <p>{selectedPenduduk.kewarganegaraan || '-'}</p>
                  </div>
                  <div>
                    <span className="text-gray-500">Status Warga:</span>
                    <p>
                      <Badge variant={selectedPenduduk.statusWarga === 'TETAP' ? 'default' : 'secondary'}>
                        {selectedPenduduk.statusWarga}
                      </Badge>
                    </p>
                  </div>
                  <div>
                    <span className="text-gray-500">BPJS:</span>
                    <p>
                      <Badge variant={selectedPenduduk.bpjs === 'Tidak' ? 'outline' : 'default'}>
                        {selectedPenduduk.bpjs}
                      </Badge>
                    </p>
                  </div>
                  <div>
                    <span className="text-gray-500">Status Keluarga:</span>
                    <p>
                      {selectedPenduduk.isKepalaKeluarga ? (
                        <Badge className="bg-emerald-600">Kepala Keluarga</Badge>
                      ) : (
                        <Badge variant="outline">Anggota Keluarga</Badge>
                      )}
                    </p>
                  </div>
                </div>
                
                <div className="border-t pt-4">
                  <h4 className="font-semibold mb-3 text-gray-700">Data Orang Tua</h4>
                  <div className="grid grid-cols-2 gap-4 text-sm">
                    <div>
                      <span className="text-gray-500">Nama Ayah:</span>
                      <p>{selectedPenduduk.namaAyah || '-'}</p>
                    </div>
                    <div>
                      <span className="text-gray-500">Nama Ibu:</span>
                      <p>{selectedPenduduk.namaIbu || '-'}</p>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          )}
          <DialogFooter className="mt-4 pt-4 border-t flex-shrink-0">
            <Button type="button" variant="outline" onClick={() => setDetailOpen(false)}>
              Tutup
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
    </div>
  )
}
