'use client'

import { useState, useEffect } from 'react'
import { Button } from '@/components/ui/button'
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card'
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from '@/components/ui/table'
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
  DialogFooter,
} from '@/components/ui/dialog'
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuTrigger,
} from '@/components/ui/dropdown-menu'
import { Input } from '@/components/ui/input'
import { Label } from '@/components/ui/label'
import { Checkbox } from '@/components/ui/checkbox'
import { Badge } from '@/components/ui/badge'
import {
  Plus,
  MoreVertical,
  Eye,
  Edit,
  Trash2,
  UserPlus,
  Upload,
  Download,
  Search,
  Users,
} from 'lucide-react'
import { useToast } from '@/hooks/use-toast'

interface KartuKeluarga {
  id: string
  noKK: string
  namaKepalaKeluarga: string
  alamat: string
  bantuan: string
  nomorHP: string
  namaAlias: string
  jumlahAnggota: number
  penduduk: Penduduk[]
}

interface Penduduk {
  id: string
  nik: string
  nama: string
  jenisKelamin: string
  isKepalaKeluarga: boolean
}

const BANTUAN_OPTIONS = ['BANSOS', 'PKH', 'BPNT', 'BLT', 'Lainnya']

export function KartuKeluargaTab() {
  const [data, setData] = useState<KartuKeluarga[]>([])
  const [loading, setLoading] = useState(true)
  const [searchTerm, setSearchTerm] = useState('')
  const [dialogOpen, setDialogOpen] = useState(false)
  const [detailOpen, setDetailOpen] = useState(false)
  const [editMode, setEditMode] = useState(false)
  const [selectedKK, setSelectedKK] = useState<KartuKeluarga | null>(null)
  const [anggotaList, setAnggotaList] = useState<Penduduk[]>([])
  const [newAnggota, setNewAnggota] = useState({
    nik: '',
    nama: '',
    jenisKelamin: 'Laki-Laki',
  })
  const [formData, setFormData] = useState({
    noKK: '',
    namaKepalaKeluarga: '',
    alamat: '',
    nomorHP: '',
    namaAlias: '',
    bantuan: [] as string[],
  })
  const { toast } = useToast()

  useEffect(() => {
    fetchData()
  }, [])

  const fetchData = async () => {
    try {
      const res = await fetch('/api/kartu-keluarga')
      const result = await res.json()
      setData(result)
    } catch (error) {
      console.error('Error fetching data:', error)
    } finally {
      setLoading(false)
    }
  }

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault()
    
    // Validasi No KK harus 16 digit
    if (!/^[0-9]{16}$/.test(formData.noKK)) {
      toast({ title: 'Error', description: 'No KK harus 16 digit angka', variant: 'destructive' })
      return
    }
    
    // Validasi NIK anggota harus 16 digit
    for (const anggota of anggotaList) {
      if (!/^[0-9]{16}$/.test(anggota.nik)) {
        toast({ title: 'Error', description: `NIK ${anggota.nama} harus 16 digit angka`, variant: 'destructive' })
        return
      }
    }
    
    try {
      const payload = {
        ...formData,
        anggota: anggotaList.map((a, i) => ({
          ...a,
          isKepalaKeluarga: i === 0,
        })),
      }

      if (editMode && selectedKK) {
        const res = await fetch(`/api/kartu-keluarga/${selectedKK.id}`, {
          method: 'PUT',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify(formData),
        })
        if (!res.ok) {
          const error = await res.json()
          throw new Error(error.error || 'Gagal mengupdate data')
        }
        toast({ title: 'Berhasil', description: 'Data kartu keluarga diupdate' })
      } else {
        const res = await fetch('/api/kartu-keluarga', {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify(payload),
        })
        if (!res.ok) {
          const error = await res.json()
          throw new Error(error.error || 'Gagal menambah data')
        }
        toast({ title: 'Berhasil', description: 'Kartu keluarga ditambahkan' })
      }

      setDialogOpen(false)
      resetForm()
      fetchData()
    } catch (error) {
      toast({
        title: 'Error',
        description: (error as Error).message,
        variant: 'destructive',
      })
    }
  }

  const handleDelete = async (id: string) => {
    if (!confirm('Yakin ingin menghapus kartu keluarga ini beserta seluruh anggotanya?')) return
    try {
      const res = await fetch(`/api/kartu-keluarga/${id}`, { method: 'DELETE' })
      if (!res.ok) throw new Error('Gagal menghapus')
      toast({ title: 'Berhasil', description: 'Kartu keluarga dihapus' })
      fetchData()
    } catch (error) {
      toast({
        title: 'Error',
        description: (error as Error).message,
        variant: 'destructive',
      })
    }
  }

  const handleViewDetail = async (kk: KartuKeluarga) => {
    try {
      const res = await fetch(`/api/kartu-keluarga/${kk.id}`)
      const result = await res.json()
      setSelectedKK(result)
      setDetailOpen(true)
    } catch (error) {
      console.error('Error fetching detail:', error)
    }
  }

  const handleEdit = (kk: KartuKeluarga) => {
    setEditMode(true)
    setSelectedKK(kk)
    setFormData({
      noKK: kk.noKK,
      namaKepalaKeluarga: kk.namaKepalaKeluarga,
      alamat: kk.alamat || '',
      nomorHP: kk.nomorHP || '',
      namaAlias: kk.namaAlias || '',
      bantuan: JSON.parse(kk.bantuan || '[]'),
    })
    setDialogOpen(true)
  }

  const handleAddAnggota = () => {
    if (!newAnggota.nik || !newAnggota.nama) {
      toast({ title: 'Error', description: 'NIK dan Nama wajib diisi', variant: 'destructive' })
      return
    }
    if (!/^[0-9]{16}$/.test(newAnggota.nik)) {
      toast({ title: 'Error', description: 'NIK harus 16 digit angka', variant: 'destructive' })
      return
    }
    // Cek duplikat NIK dalam list
    if (anggotaList.some(a => a.nik === newAnggota.nik)) {
      toast({ title: 'Error', description: 'NIK sudah ada dalam daftar anggota', variant: 'destructive' })
      return
    }
    setAnggotaList([...anggotaList, { id: `temp-${Date.now()}`, ...newAnggota, isKepalaKeluarga: anggotaList.length === 0 }])
    setNewAnggota({ nik: '', nama: '', jenisKelamin: 'Laki-Laki' })
  }

  const handleRemoveAnggota = (id: string) => {
    setAnggotaList(anggotaList.filter((a) => a.id !== id))
  }

  const handleBantuanChange = (value: string, checked: boolean) => {
    if (checked) {
      setFormData({ ...formData, bantuan: [...formData.bantuan, value] })
    } else {
      setFormData({ ...formData, bantuan: formData.bantuan.filter((b) => b !== value) })
    }
  }

  const resetForm = () => {
    setFormData({
      noKK: '',
      namaKepalaKeluarga: '',
      alamat: '',
      nomorHP: '',
      namaAlias: '',
      bantuan: [],
    })
    setAnggotaList([])
    setEditMode(false)
    setSelectedKK(null)
  }

  const handleImport = async (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0]
    if (!file) return

    const formData = new FormData()
    formData.append('file', file)

    try {
      const res = await fetch('/api/import', {
        method: 'POST',
        body: formData,
      })
      const result = await res.json()
      toast({
        title: 'Import Berhasil',
        description: `${result.importedKK} KK dan ${result.importedPenduduk} penduduk diimport`,
      })
      fetchData()
    } catch (error) {
      toast({
        title: 'Error',
        description: 'Gagal import data',
        variant: 'destructive',
      })
    }
    e.target.value = ''
  }

  const handleExport = () => {
    window.open('/api/export?type=kartu-keluarga', '_blank')
  }

  const filteredData = data.filter(
    (kk) =>
      kk.noKK.toLowerCase().includes(searchTerm.toLowerCase()) ||
      kk.namaKepalaKeluarga.toLowerCase().includes(searchTerm.toLowerCase())
  )

  if (loading) {
    return (
      <div className="flex items-center justify-center h-64">
        <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-emerald-600"></div>
      </div>
    )
  }

  return (
    <div className="space-y-4">
      {/* Action Buttons */}
      <div className="flex flex-wrap gap-2">
        <Button onClick={() => { resetForm(); setDialogOpen(true) }} className="bg-emerald-600 hover:bg-emerald-700">
          <Plus className="h-4 w-4 mr-2" />
          Tambah KK
        </Button>
        <label className="cursor-pointer">
          <input type="file" accept=".xlsx,.xls" onChange={handleImport} className="hidden" />
          <Button variant="outline" asChild>
            <span>
              <Upload className="h-4 w-4 mr-2" />
              Import
            </span>
          </Button>
        </label>
        <Button variant="outline" onClick={handleExport}>
          <Download className="h-4 w-4 mr-2" />
          Export
        </Button>
      </div>

      {/* Search */}
      <div className="relative">
        <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 h-4 w-4 text-gray-400" />
        <Input
          placeholder="Cari No KK atau Nama Kepala Keluarga..."
          value={searchTerm}
          onChange={(e) => setSearchTerm(e.target.value)}
          className="pl-10"
        />
      </div>

      {/* Table */}
      <Card>
        <CardContent className="p-0">
          <div className="overflow-x-auto">
            <Table>
              <TableHeader>
                <TableRow>
                  <TableHead className="w-12">No</TableHead>
                  <TableHead>No KK</TableHead>
                  <TableHead>Nama Kepala Keluarga</TableHead>
                  <TableHead>Jumlah Anggota</TableHead>
                  <TableHead>Bantuan</TableHead>
                  <TableHead className="w-24">Aksi</TableHead>
                </TableRow>
              </TableHeader>
              <TableBody>
                {filteredData.length === 0 ? (
                  <TableRow>
                    <TableCell colSpan={6} className="text-center py-8 text-gray-500">
                      Tidak ada data
                    </TableCell>
                  </TableRow>
                ) : (
                  filteredData.map((kk, index) => (
                    <TableRow key={kk.id}>
                      <TableCell>{index + 1}</TableCell>
                      <TableCell className="font-mono">{kk.noKK}</TableCell>
                      <TableCell>{kk.namaKepalaKeluarga}</TableCell>
                      <TableCell>
                        <Badge variant="secondary">{kk.jumlahAnggota} orang</Badge>
                      </TableCell>
                      <TableCell>
                        {(() => {
                          const bantuan = JSON.parse(kk.bantuan || '[]')
                          return bantuan.length > 0 ? (
                            <div className="flex flex-wrap gap-1">
                              {bantuan.map((b: string) => (
                                <Badge key={b} variant="outline" className="text-xs">
                                  {b}
                                </Badge>
                              ))}
                            </div>
                          ) : (
                            '-'
                          )
                        })()}
                      </TableCell>
                      <TableCell>
                        <DropdownMenu>
                          <DropdownMenuTrigger asChild>
                            <Button variant="ghost" size="sm">
                              <MoreVertical className="h-4 w-4" />
                            </Button>
                          </DropdownMenuTrigger>
                          <DropdownMenuContent align="end">
                            <DropdownMenuItem onClick={() => handleViewDetail(kk)}>
                              <Eye className="h-4 w-4 mr-2" />
                              Lihat Detail
                            </DropdownMenuItem>
                            <DropdownMenuItem onClick={() => handleEdit(kk)}>
                              <Edit className="h-4 w-4 mr-2" />
                              Edit
                            </DropdownMenuItem>
                            <DropdownMenuItem onClick={() => handleDelete(kk.id)} className="text-red-600">
                              <Trash2 className="h-4 w-4 mr-2" />
                              Hapus
                            </DropdownMenuItem>
                          </DropdownMenuContent>
                        </DropdownMenu>
                      </TableCell>
                    </TableRow>
                  ))
                )}
              </TableBody>
            </Table>
          </div>
        </CardContent>
      </Card>

      {/* Dialog Tambah/Edit KK */}
      <Dialog open={dialogOpen} onOpenChange={setDialogOpen}>
        <DialogContent className="max-w-2xl max-h-[90vh] overflow-hidden flex flex-col">
          <DialogHeader>
            <DialogTitle>{editMode ? 'Edit Kartu Keluarga' : 'Tambah Kartu Keluarga Baru'}</DialogTitle>
          </DialogHeader>
          <form onSubmit={handleSubmit} className="flex flex-col flex-1 overflow-hidden">
            <div className="flex-1 overflow-y-auto pr-2 -mr-2">
              <div className="space-y-4">
                <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                  <div>
                    <Label htmlFor="noKK">No KK * (16 digit)</Label>
                    <Input
                      id="noKK"
                      value={formData.noKK}
                      onChange={(e) => setFormData({ ...formData, noKK: e.target.value.replace(/\D/g, '').slice(0, 16) })}
                      required
                      placeholder="320116..."
                      maxLength={16}
                    />
                    {formData.noKK.length > 0 && formData.noKK.length !== 16 && (
                      <p className="text-xs text-red-500 mt-1">No KK harus 16 digit ({formData.noKK.length}/16)</p>
                    )}
                  </div>
                  <div>
                    <Label htmlFor="namaKepalaKeluarga">Nama Kepala Keluarga *</Label>
                    <Input
                      id="namaKepalaKeluarga"
                      value={formData.namaKepalaKeluarga}
                      onChange={(e) => setFormData({ ...formData, namaKepalaKeluarga: e.target.value })}
                      required
                    />
                  </div>
                </div>

                <div>
                  <Label htmlFor="alamat">Alamat</Label>
                  <Input
                    id="alamat"
                    value={formData.alamat}
                    onChange={(e) => setFormData({ ...formData, alamat: e.target.value })}
                  />
                </div>

                <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                  <div>
                    <Label htmlFor="nomorHP">Nomor HP</Label>
                    <Input
                      id="nomorHP"
                      value={formData.nomorHP}
                      onChange={(e) => setFormData({ ...formData, nomorHP: e.target.value })}
                    />
                  </div>
                  <div>
                    <Label htmlFor="namaAlias">Nama Alias/Panggilan</Label>
                    <Input
                      id="namaAlias"
                      value={formData.namaAlias}
                      onChange={(e) => setFormData({ ...formData, namaAlias: e.target.value })}
                    />
                  </div>
                </div>

                <div>
                  <Label>Bantuan (pilih lebih dari satu jika perlu)</Label>
                  <div className="flex flex-wrap gap-4 mt-2">
                    {BANTUAN_OPTIONS.map((option) => (
                      <label key={option} className="flex items-center gap-2">
                        <Checkbox
                          checked={formData.bantuan.includes(option)}
                          onCheckedChange={(checked) => handleBantuanChange(option, checked as boolean)}
                        />
                        <span className="text-sm">{option}</span>
                      </label>
                    ))}
                  </div>
                </div>

                {!editMode && (
                  <div className="border-t pt-4">
                    <div className="flex items-center justify-between mb-3">
                      <Label className="text-base font-semibold">Anggota Keluarga</Label>
                      <span className="text-sm text-gray-500">{anggotaList.length} anggota</span>
                    </div>

                    {/* Add new member form */}
                    <div className="bg-gray-50 p-3 rounded-lg mb-3">
                      <div className="grid grid-cols-1 md:grid-cols-3 gap-2 mb-2">
                        <div>
                          <Input
                            placeholder="NIK (16 digit)"
                            value={newAnggota.nik}
                            onChange={(e) => setNewAnggota({ ...newAnggota, nik: e.target.value.replace(/\D/g, '').slice(0, 16) })}
                            maxLength={16}
                          />
                          {newAnggota.nik.length > 0 && newAnggota.nik.length !== 16 && (
                            <p className="text-xs text-red-500 mt-1">NIK harus 16 digit</p>
                          )}
                        </div>
                        <Input
                          placeholder="Nama"
                          value={newAnggota.nama}
                          onChange={(e) => setNewAnggota({ ...newAnggota, nama: e.target.value })}
                        />
                        <select
                          className="border rounded px-3 py-2"
                          value={newAnggota.jenisKelamin}
                          onChange={(e) => setNewAnggota({ ...newAnggota, jenisKelamin: e.target.value })}
                        >
                          <option value="Laki-Laki">Laki-Laki</option>
                          <option value="Perempuan">Perempuan</option>
                        </select>
                      </div>
                      <Button type="button" size="sm" onClick={handleAddAnggota}>
                        <UserPlus className="h-4 w-4 mr-1" />
                        Tambah Anggota
                      </Button>
                    </div>

                    {/* Member list */}
                    {anggotaList.length > 0 && (
                      <div className="space-y-2">
                        {anggotaList.map((anggota, index) => (
                          <div key={anggota.id} className="flex items-center justify-between bg-white p-2 border rounded">
                            <div>
                              <span className="font-medium">{anggota.nama}</span>
                              <span className="text-gray-500 text-sm ml-2">({anggota.nik})</span>
                              <Badge variant="outline" className="ml-2">{anggota.jenisKelamin}</Badge>
                              {index === 0 && <Badge className="ml-2 bg-emerald-600">Kepala Keluarga</Badge>}
                            </div>
                            <Button
                              type="button"
                              variant="ghost"
                              size="sm"
                              onClick={() => handleRemoveAnggota(anggota.id)}
                            >
                              <Trash2 className="h-4 w-4 text-red-500" />
                            </Button>
                          </div>
                        ))}
                      </div>
                    )}
                  </div>
                )}
              </div>
            </div>
            <DialogFooter className="mt-4 pt-4 border-t flex-shrink-0">
              <Button type="button" variant="outline" onClick={() => setDialogOpen(false)}>
                Batal
              </Button>
              <Button type="submit" className="bg-emerald-600 hover:bg-emerald-700">
                {editMode ? 'Update' : 'Simpan'}
              </Button>
            </DialogFooter>
          </form>
        </DialogContent>
      </Dialog>

      {/* Dialog Detail */}
      <Dialog open={detailOpen} onOpenChange={setDetailOpen}>
        <DialogContent className="max-w-2xl max-h-[90vh] overflow-hidden flex flex-col">
          <DialogHeader>
            <DialogTitle>Detail Kartu Keluarga</DialogTitle>
          </DialogHeader>
          {selectedKK && (
            <div className="flex-1 overflow-y-auto pr-2 -mr-2">
              <div className="space-y-4">
                <div className="grid grid-cols-2 gap-4 text-sm">
                  <div>
                    <span className="text-gray-500">No KK:</span>
                    <p className="font-mono font-semibold">{selectedKK.noKK}</p>
                  </div>
                  <div>
                    <span className="text-gray-500">Kepala Keluarga:</span>
                    <p className="font-semibold">{selectedKK.namaKepalaKeluarga}</p>
                  </div>
                  <div>
                    <span className="text-gray-500">Alamat:</span>
                    <p>{selectedKK.alamat || '-'}</p>
                  </div>
                  <div>
                    <span className="text-gray-500">No HP:</span>
                    <p>{selectedKK.nomorHP || '-'}</p>
                  </div>
                </div>

                <div>
                  <h4 className="font-semibold mb-2 flex items-center gap-2">
                    <Users className="h-4 w-4" />
                    Anggota Keluarga ({selectedKK.penduduk?.length || 0} orang)
                  </h4>
                  <Table>
                    <TableHeader>
                      <TableRow>
                        <TableHead>No</TableHead>
                        <TableHead>NIK</TableHead>
                        <TableHead>Nama</TableHead>
                        <TableHead>Jenis Kelamin</TableHead>
                        <TableHead>Status</TableHead>
                      </TableRow>
                    </TableHeader>
                    <TableBody>
                      {selectedKK.penduduk?.map((p, index) => (
                        <TableRow key={p.id}>
                          <TableCell>{index + 1}</TableCell>
                          <TableCell className="font-mono">{p.nik}</TableCell>
                          <TableCell>{p.nama}</TableCell>
                          <TableCell>{p.jenisKelamin}</TableCell>
                          <TableCell>
                            {p.isKepalaKeluarga ? (
                              <Badge className="bg-emerald-600">Kepala Keluarga</Badge>
                            ) : (
                              <Badge variant="outline">Anggota</Badge>
                            )}
                          </TableCell>
                        </TableRow>
                      ))}
                    </TableBody>
                  </Table>
                </div>
              </div>
            </div>
          )}
        </DialogContent>
      </Dialog>
    </div>
  )
}
