'use client'

import { useState, useEffect } from 'react'
import { Button } from '@/components/ui/button'
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card'
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from '@/components/ui/table'
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
  DialogFooter,
} from '@/components/ui/dialog'
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from '@/components/ui/select'
import { Input } from '@/components/ui/input'
import { Label } from '@/components/ui/label'
import { Badge } from '@/components/ui/badge'
import {
  Plus,
  Trash2,
  Baby,
  HeartCrack,
  MoveRight,
  MoveLeft,
  Users,
  Edit,
  UserPlus,
  X,
} from 'lucide-react'
import { useToast } from '@/hooks/use-toast'

interface Kejadian {
  id: string
  jenisKejadian: string
  pendudukId: string | null
  noKKId: string | null
  tanggalKejadian: string
  keterangan: string
  penduduk?: {
    id: string
    nik: string
    nama: string
    jenisKelamin: string
  }
  kartuKeluarga?: {
    id: string
    noKK: string
    namaKepalaKeluarga: string
  }
}

interface KartuKeluargaOption {
  id: string
  noKK: string
  namaKepalaKeluarga: string
  penduduk: {
    id: string
    nik: string
    nama: string
    jenisKelamin: string
    isKepalaKeluarga: boolean
  }[]
}

interface Statistik {
  kejadian: {
    lahir: { total: number; l: number; p: number }
    meninggal: { total: number; l: number; p: number }
    pindah: { total: number; l: number; p: number }
    datang: { total: number; l: number; p: number }
  }
}

const JENIS_KEJADIAN_OPTIONS = [
  { value: 'LAHIR', label: 'Lahir', icon: Baby },
  { value: 'MENINGGAL', label: 'Meninggal', icon: HeartCrack },
  { value: 'PINDAH', label: 'Pindah', icon: MoveRight },
  { value: 'DATANG', label: 'Datang', icon: MoveLeft },
]

export function KejadianTab() {
  const [data, setData] = useState<Kejadian[]>([])
  const [kkOptions, setKkOptions] = useState<KartuKeluargaOption[]>([])
  const [statistik, setStatistik] = useState<Statistik | null>(null)
  const [loading, setLoading] = useState(true)
  const [dialogOpen, setDialogOpen] = useState(false)
  const [editMode, setEditMode] = useState(false)
  const [selectedKejadian, setSelectedKejadian] = useState<Kejadian | null>(null)
  const [selectedJenis, setSelectedJenis] = useState('LAHIR')
  const [selectedKK, setSelectedKK] = useState('')
  const [selectedPenduduk, setSelectedPenduduk] = useState('')
  const [pendudukList, setPendudukList] = useState<{ id: string; nik: string; nama: string; jenisKelamin: string }[]>([])
  
  // Form states
  const [formData, setFormData] = useState({
    tanggalKejadian: new Date().toISOString().split('T')[0],
    keterangan: '',
    // Lahir
    nikBayi: '',
    namaBayi: '',
    jenisKelaminBayi: 'Laki-Laki',
    tempatLahirBayi: '',
    namaAyahBayi: '',
    namaIbuBayi: '',
    // Datang
    nikDatang: '',
    namaDatang: '',
    jenisKelaminDatang: 'Laki-Laki',
    tempatLahirDatang: '',
    tanggalLahirDatang: '',
    // KK Baru untuk datang
    buatKKBaru: false,
    noKKBaru: '',
    namaKepalaKeluargaBaru: '',
    // Pindah semua keluarga
    pindahSemua: false,
  })
  // Anggota keluarga tambahan untuk Datang
  const [anggotaDatang, setAnggotaDatang] = useState<Array<{
    nik: string
    nama: string
    jenisKelamin: string
    tempatLahir: string
    tanggalLahir: string
    namaAyah: string
    namaIbu: string
    namaPanggilan: string
    bpjs: string
  }>>([])

  const { toast } = useToast()

  useEffect(() => {
    fetchData()
    fetchKKOptions()
    fetchStatistik()
  }, [])

  const fetchData = async () => {
    try {
      const res = await fetch('/api/kejadian')
      const result = await res.json()
      setData(result)
    } catch (error) {
      console.error('Error fetching data:', error)
    } finally {
      setLoading(false)
    }
  }

  const fetchKKOptions = async () => {
    try {
      const res = await fetch('/api/kartu-keluarga')
      const result = await res.json()
      setKkOptions(result)
    } catch (error) {
      console.error('Error fetching KK options:', error)
    }
  }

  const fetchStatistik = async () => {
    try {
      const res = await fetch('/api/statistik')
      const result = await res.json()
      setStatistik(result)
    } catch (error) {
      console.error('Error fetching statistik:', error)
    }
  }

  useEffect(() => {
    if (selectedKK) {
      const kk = kkOptions.find((k) => k.id === selectedKK)
      if (kk) {
        setPendudukList(kk.penduduk)
      }
    } else {
      setPendudukList([])
    }
  }, [selectedKK, kkOptions])

  const handleEdit = async (kejadian: Kejadian) => {
    setEditMode(true)
    setSelectedKejadian(kejadian)
    setSelectedJenis(kejadian.jenisKejadian)
    setFormData({
      ...formData,
      tanggalKejadian: kejadian.tanggalKejadian ? kejadian.tanggalKejadian.split('T')[0] : new Date().toISOString().split('T')[0],
      keterangan: kejadian.keterangan || '',
    })
    if (kejadian.noKKId) {
      setSelectedKK(kejadian.noKKId)
    }
    if (kejadian.pendudukId) {
      setSelectedPenduduk(kejadian.pendudukId)
    }
    setDialogOpen(true)
  }

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault()
    try {
      // Edit mode - hanya update tanggal dan keterangan
      if (editMode && selectedKejadian) {
        const res = await fetch(`/api/kejadian/${selectedKejadian.id}`, {
          method: 'PUT',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({
            tanggalKejadian: formData.tanggalKejadian,
            keterangan: formData.keterangan,
          }),
        })
        if (!res.ok) throw new Error('Gagal mengupdate kejadian')
        toast({ title: 'Berhasil', description: 'Kejadian diupdate' })
        setDialogOpen(false)
        resetForm()
        fetchData()
        fetchStatistik()
        return
      }

      // Create mode
      let payload: Record<string, unknown> = {
        jenisKejadian: selectedJenis,
        tanggalKejadian: formData.tanggalKejadian,
        keterangan: formData.keterangan,
        noKKId: selectedKK || null,
        pendudukId: selectedPenduduk || null,
      }

      if (selectedJenis === 'LAHIR') {
        if (!selectedKK) {
          toast({ title: 'Error', description: 'Pilih No KK yang melahirkan', variant: 'destructive' })
          return
        }
        payload.pendudukBaru = {
          nik: formData.nikBayi,
          nama: formData.namaBayi,
          jenisKelamin: formData.jenisKelaminBayi,
          tempatLahir: formData.tempatLahirBayi,
          namaAyah: formData.namaAyahBayi,
          namaIbu: formData.namaIbuBayi,
        }
      } else if (selectedJenis === 'DATANG') {
        if (!selectedKK && !formData.buatKKBaru) {
          toast({ title: 'Error', description: 'Pilih No KK tujuan atau buat KK baru', variant: 'destructive' })
          return
        }
        if (formData.buatKKBaru) {
          payload.kkBaru = {
            noKK: formData.noKKBaru,
            namaKepalaKeluarga: formData.namaKepalaKeluargaBaru,
          }
          // Kepala keluarga + anggota tambahan
          const semuaAnggota = [
            {
              nik: formData.nikDatang,
              nama: formData.namaDatang,
              jenisKelamin: formData.jenisKelaminDatang,
              tempatLahir: formData.tempatLahirDatang,
              tanggalLahir: formData.tanggalLahirDatang,
              isKepalaKeluarga: true,
            },
            ...anggotaDatang.filter(a => a.nik && a.nama).map(a => ({
              nik: a.nik,
              nama: a.nama,
              jenisKelamin: a.jenisKelamin,
              tempatLahir: a.tempatLahir,
              tanggalLahir: a.tanggalLahir,
              namaAyah: a.namaAyah,
              namaIbu: a.namaIbu,
              namaPanggilan: a.namaPanggilan,
              bpjs: a.bpjs,
              isKepalaKeluarga: false,
            }))
          ]
          payload.pendudukBaru = semuaAnggota
        } else {
          // Tambah ke KK yang ada - utama + anggota tambahan
          const semuaAnggota = [
            {
              nik: formData.nikDatang,
              nama: formData.namaDatang,
              jenisKelamin: formData.jenisKelaminDatang,
              tempatLahir: formData.tempatLahirDatang,
              tanggalLahir: formData.tanggalLahirDatang,
            },
            ...anggotaDatang.filter(a => a.nik && a.nama).map(a => ({
              nik: a.nik,
              nama: a.nama,
              jenisKelamin: a.jenisKelamin,
              tempatLahir: a.tempatLahir,
              tanggalLahir: a.tanggalLahir,
              namaAyah: a.namaAyah,
              namaIbu: a.namaIbu,
              namaPanggilan: a.namaPanggilan,
              bpjs: a.bpjs,
            }))
          ]
          payload.pendudukBaru = semuaAnggota
        }
      } else if (selectedJenis === 'PINDAH') {
        payload.pindahSemua = formData.pindahSemua
      }

      const res = await fetch('/api/kejadian', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(payload),
      })

      if (!res.ok) throw new Error('Gagal menambah kejadian')
      toast({ title: 'Berhasil', description: 'Kejadian ditambahkan' })
      setDialogOpen(false)
      resetForm()
      fetchData()
      fetchStatistik()
    } catch (error) {
      toast({
        title: 'Error',
        description: (error as Error).message,
        variant: 'destructive',
      })
    }
  }

  const handleDelete = async (id: string) => {
    if (!confirm('Yakin ingin menghapus kejadian ini?')) return
    try {
      const res = await fetch(`/api/kejadian/${id}`, { method: 'DELETE' })
      if (!res.ok) throw new Error('Gagal menghapus')
      toast({ title: 'Berhasil', description: 'Kejadian dihapus' })
      fetchData()
      fetchStatistik()
    } catch (error) {
      toast({
        title: 'Error',
        description: (error as Error).message,
        variant: 'destructive',
      })
    }
  }

  const resetForm = () => {
    setFormData({
      tanggalKejadian: new Date().toISOString().split('T')[0],
      keterangan: '',
      nikBayi: '',
      namaBayi: '',
      jenisKelaminBayi: 'Laki-Laki',
      tempatLahirBayi: '',
      namaAyahBayi: '',
      namaIbuBayi: '',
      nikDatang: '',
      namaDatang: '',
      jenisKelaminDatang: 'Laki-Laki',
      tempatLahirDatang: '',
      tanggalLahirDatang: '',
      buatKKBaru: false,
      noKKBaru: '',
      namaKepalaKeluargaBaru: '',
      pindahSemua: false,
    })
    setAnggotaDatang([])
    setSelectedKK('')
    setSelectedPenduduk('')
    setEditMode(false)
    setSelectedKejadian(null)
    setSelectedJenis('LAHIR')
  }

  const addAnggotaDatang = () => {
    setAnggotaDatang([
      ...anggotaDatang,
      {
        nik: '',
        nama: '',
        jenisKelamin: 'Laki-Laki',
        tempatLahir: '',
        tanggalLahir: '',
        namaAyah: '',
        namaIbu: '',
        namaPanggilan: '',
        bpjs: 'Tidak',
      },
    ])
  }

  const removeAnggotaDatang = (index: number) => {
    setAnggotaDatang(anggotaDatang.filter((_, i) => i !== index))
  }

  const updateAnggotaDatang = (index: number, field: string, value: string) => {
    const updated = [...anggotaDatang]
    updated[index] = { ...updated[index], [field]: value }
    setAnggotaDatang(updated)
  }

  const formatDate = (date: string) => {
    const d = new Date(date)
    return `${d.getDate().toString().padStart(2, '0')}/${(d.getMonth() + 1).toString().padStart(2, '0')}/${d.getFullYear()}`
  }

  const getBadgeColor = (jenis: string) => {
    switch (jenis) {
      case 'LAHIR':
        return 'bg-green-500'
      case 'MENINGGAL':
        return 'bg-gray-500'
      case 'PINDAH':
        return 'bg-orange-500'
      case 'DATANG':
        return 'bg-blue-500'
      default:
        return 'bg-gray-500'
    }
  }

  if (loading) {
    return (
      <div className="flex items-center justify-center h-64">
        <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-emerald-600"></div>
      </div>
    )
  }

  return (
    <div className="space-y-4">
      {/* Statistics Cards */}
      <div className="grid grid-cols-2 md:grid-cols-4 gap-3">
        <Card className="bg-gradient-to-br from-green-500 to-green-600 text-white">
          <CardContent className="pt-4">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm text-green-100">Lahir</p>
                <p className="text-2xl font-bold">{statistik?.kejadian.lahir.total || 0}</p>
                <p className="text-xs text-green-100">L: {statistik?.kejadian.lahir.l || 0} | P: {statistik?.kejadian.lahir.p || 0}</p>
              </div>
              <Baby className="h-8 w-8 opacity-50" />
            </div>
          </CardContent>
        </Card>

        <Card className="bg-gradient-to-br from-gray-500 to-gray-600 text-white">
          <CardContent className="pt-4">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm text-gray-100">Meninggal</p>
                <p className="text-2xl font-bold">{statistik?.kejadian.meninggal.total || 0}</p>
                <p className="text-xs text-gray-100">L: {statistik?.kejadian.meninggal.l || 0} | P: {statistik?.kejadian.meninggal.p || 0}</p>
              </div>
              <HeartCrack className="h-8 w-8 opacity-50" />
            </div>
          </CardContent>
        </Card>

        <Card className="bg-gradient-to-br from-orange-500 to-orange-600 text-white">
          <CardContent className="pt-4">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm text-orange-100">Pindah</p>
                <p className="text-2xl font-bold">{statistik?.kejadian.pindah.total || 0}</p>
                <p className="text-xs text-orange-100">L: {statistik?.kejadian.pindah.l || 0} | P: {statistik?.kejadian.pindah.p || 0}</p>
              </div>
              <MoveRight className="h-8 w-8 opacity-50" />
            </div>
          </CardContent>
        </Card>

        <Card className="bg-gradient-to-br from-blue-500 to-blue-600 text-white">
          <CardContent className="pt-4">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm text-blue-100">Datang</p>
                <p className="text-2xl font-bold">{statistik?.kejadian.datang.total || 0}</p>
                <p className="text-xs text-blue-100">L: {statistik?.kejadian.datang.l || 0} | P: {statistik?.kejadian.datang.p || 0}</p>
              </div>
              <MoveLeft className="h-8 w-8 opacity-50" />
            </div>
          </CardContent>
        </Card>
      </div>

      {/* Action Button */}
      <Button onClick={() => { resetForm(); setEditMode(false); setDialogOpen(true) }} className="bg-emerald-600 hover:bg-emerald-700">
        <Plus className="h-4 w-4 mr-2" />
        Tambah Kejadian
      </Button>

      {/* Table */}
      <Card>
        <CardHeader className="py-3">
          <CardTitle className="text-base">Data Penduduk Kejadian</CardTitle>
        </CardHeader>
        <CardContent className="p-0">
          <div className="overflow-x-auto">
            <Table>
              <TableHeader>
                <TableRow>
                  <TableHead>Tanggal</TableHead>
                  <TableHead>Jenis</TableHead>
                  <TableHead>NIK</TableHead>
                  <TableHead>Nama</TableHead>
                  <TableHead>No KK</TableHead>
                  <TableHead>Keterangan</TableHead>
                  <TableHead className="w-16">Aksi</TableHead>
                </TableRow>
              </TableHeader>
              <TableBody>
                {data.length === 0 ? (
                  <TableRow>
                    <TableCell colSpan={7} className="text-center py-8 text-gray-500">
                      Tidak ada data
                    </TableCell>
                  </TableRow>
                ) : (
                  data.map((k) => (
                    <TableRow key={k.id}>
                      <TableCell className="text-xs">{formatDate(k.tanggalKejadian)}</TableCell>
                      <TableCell>
                        <Badge className={`${getBadgeColor(k.jenisKejadian)} text-white`}>
                          {k.jenisKejadian}
                        </Badge>
                      </TableCell>
                      <TableCell className="font-mono text-xs">{k.penduduk?.nik || '-'}</TableCell>
                      <TableCell>{k.penduduk?.nama || '-'}</TableCell>
                      <TableCell className="font-mono text-xs">{k.kartuKeluarga?.noKK || '-'}</TableCell>
                      <TableCell className="text-xs">{k.keterangan || '-'}</TableCell>
                      <TableCell>
                        <div className="flex gap-1">
                          <Button
                            variant="ghost"
                            size="sm"
                            onClick={() => handleEdit(k)}
                            title="Edit"
                          >
                            <Edit className="h-4 w-4" />
                          </Button>
                          <Button
                            variant="ghost"
                            size="sm"
                            onClick={() => handleDelete(k.id)}
                            title="Hapus"
                          >
                            <Trash2 className="h-4 w-4 text-red-500" />
                          </Button>
                        </div>
                      </TableCell>
                    </TableRow>
                  ))
                )}
              </TableBody>
            </Table>
          </div>
        </CardContent>
      </Card>

      {/* Dialog Tambah Kejadian */}
      <Dialog open={dialogOpen} onOpenChange={setDialogOpen}>
        <DialogContent className="max-w-2xl max-h-[90vh] overflow-hidden flex flex-col">
          <DialogHeader>
            <DialogTitle>{editMode ? 'Edit Kejadian' : 'Tambah Kejadian'}</DialogTitle>
          </DialogHeader>
          <form onSubmit={handleSubmit} className="flex flex-col flex-1 overflow-hidden">
            <div className="flex-1 overflow-y-auto pr-2 -mr-2">
              <div className="space-y-4">
                {/* Jenis Kejadian */}
                <div>
                  <Label>Jenis Kejadian</Label>
                  <div className="grid grid-cols-2 md:grid-cols-4 gap-2 mt-2">
                    {JENIS_KEJADIAN_OPTIONS.map((opt) => (
                      <Button
                        key={opt.value}
                        type="button"
                        variant={selectedJenis === opt.value ? 'default' : 'outline'}
                        className={`h-auto py-2 ${selectedJenis === opt.value ? 'bg-emerald-600' : ''}`}
                        onClick={() => setSelectedJenis(opt.value)}
                      >
                        <opt.icon className="h-4 w-4 mr-2" />
                        {opt.label}
                      </Button>
                    ))}
                  </div>
                </div>

                {/* Tanggal */}
                <div>
                  <Label htmlFor="tanggalKejadian">Tanggal Kejadian</Label>
                  <Input
                    id="tanggalKejadian"
                    type="date"
                    value={formData.tanggalKejadian}
                    onChange={(e) => setFormData({ ...formData, tanggalKejadian: e.target.value })}
                  />
                </div>

                {/* LAHIR Form */}
                {selectedJenis === 'LAHIR' && (
                  <>
                    <div>
                      <Label>Pilih No KK yang Melahirkan</Label>
                      <Select value={selectedKK} onValueChange={setSelectedKK}>
                        <SelectTrigger>
                          <SelectValue placeholder="Pilih No KK" />
                        </SelectTrigger>
                        <SelectContent>
                          {kkOptions.map((kk) => (
                            <SelectItem key={kk.id} value={kk.id}>
                              {kk.noKK} - {kk.namaKepalaKeluarga}
                            </SelectItem>
                          ))}
                        </SelectContent>
                      </Select>
                    </div>
                    <div className="border-t pt-4">
                      <Label className="font-semibold">Data Bayi</Label>
                      <div className="grid grid-cols-1 md:grid-cols-2 gap-3 mt-2">
                        <Input placeholder="NIK Bayi" value={formData.nikBayi} onChange={(e) => setFormData({ ...formData, nikBayi: e.target.value })} required />
                        <Input placeholder="Nama Bayi" value={formData.namaBayi} onChange={(e) => setFormData({ ...formData, namaBayi: e.target.value })} required />
                        <Select value={formData.jenisKelaminBayi} onValueChange={(v) => setFormData({ ...formData, jenisKelaminBayi: v })}>
                          <SelectTrigger><SelectValue /></SelectTrigger>
                          <SelectContent>
                            <SelectItem value="Laki-Laki">Laki-Laki</SelectItem>
                            <SelectItem value="Perempuan">Perempuan</SelectItem>
                          </SelectContent>
                        </Select>
                        <Input placeholder="Tempat Lahir" value={formData.tempatLahirBayi} onChange={(e) => setFormData({ ...formData, tempatLahirBayi: e.target.value })} />
                        <Input placeholder="Nama Ayah" value={formData.namaAyahBayi} onChange={(e) => setFormData({ ...formData, namaAyahBayi: e.target.value })} />
                        <Input placeholder="Nama Ibu" value={formData.namaIbuBayi} onChange={(e) => setFormData({ ...formData, namaIbuBayi: e.target.value })} />
                      </div>
                    </div>
                  </>
                )}

                {/* MENINGGAL Form */}
                {selectedJenis === 'MENINGGAL' && (
                  <>
                    <div>
                      <Label>Pilih No KK</Label>
                      <Select value={selectedKK} onValueChange={setSelectedKK}>
                        <SelectTrigger>
                          <SelectValue placeholder="Pilih No KK" />
                        </SelectTrigger>
                        <SelectContent>
                          {kkOptions.map((kk) => (
                            <SelectItem key={kk.id} value={kk.id}>
                              {kk.noKK} - {kk.namaKepalaKeluarga}
                            </SelectItem>
                          ))}
                        </SelectContent>
                      </Select>
                    </div>
                    <div>
                      <Label>Pilih NIK yang Meninggal</Label>
                      <Select value={selectedPenduduk} onValueChange={setSelectedPenduduk}>
                        <SelectTrigger>
                          <SelectValue placeholder="Pilih NIK" />
                        </SelectTrigger>
                        <SelectContent>
                          {pendudukList.map((p) => (
                            <SelectItem key={p.id} value={p.id}>
                              {p.nik} - {p.nama}
                            </SelectItem>
                          ))}
                        </SelectContent>
                      </Select>
                    </div>
                  </>
                )}

                {/* PINDAH Form */}
                {selectedJenis === 'PINDAH' && (
                  <>
                    <div className="flex items-center gap-2">
                      <input
                        type="checkbox"
                        id="pindahSemua"
                        checked={formData.pindahSemua}
                        onChange={(e) => setFormData({ ...formData, pindahSemua: e.target.checked })}
                        className="rounded"
                      />
                      <Label htmlFor="pindahSemua">Pindah Semua Keluarga</Label>
                    </div>
                    
                    {!formData.pindahSemua && (
                      <>
                        <div>
                          <Label>Pilih No KK</Label>
                          <Select value={selectedKK} onValueChange={setSelectedKK}>
                            <SelectTrigger>
                              <SelectValue placeholder="Pilih No KK" />
                            </SelectTrigger>
                            <SelectContent>
                              {kkOptions.map((kk) => (
                                <SelectItem key={kk.id} value={kk.id}>
                                  {kk.noKK} - {kk.namaKepalaKeluarga}
                                </SelectItem>
                              ))}
                            </SelectContent>
                          </Select>
                        </div>
                        <div>
                          <Label>Pilih NIK yang Pindah</Label>
                          <Select value={selectedPenduduk} onValueChange={setSelectedPenduduk}>
                            <SelectTrigger>
                              <SelectValue placeholder="Pilih NIK" />
                            </SelectTrigger>
                            <SelectContent>
                              {pendudukList.map((p) => (
                                <SelectItem key={p.id} value={p.id}>
                                  {p.nik} - {p.nama}
                                </SelectItem>
                              ))}
                            </SelectContent>
                          </Select>
                        </div>
                      </>
                    )}
                    
                    {formData.pindahSemua && (
                      <div>
                        <Label>Pilih No KK yang Pindah</Label>
                        <Select value={selectedKK} onValueChange={setSelectedKK}>
                          <SelectTrigger>
                            <SelectValue placeholder="Pilih No KK" />
                          </SelectTrigger>
                          <SelectContent>
                            {kkOptions.map((kk) => (
                              <SelectItem key={kk.id} value={kk.id}>
                                {kk.noKK} - {kk.namaKepalaKeluarga}
                              </SelectItem>
                            ))}
                          </SelectContent>
                        </Select>
                      </div>
                    )}
                  </>
                )}

                {/* DATANG Form */}
                {selectedJenis === 'DATANG' && (
                  <>
                    <div className="flex items-center gap-2">
                      <input
                        type="checkbox"
                        id="buatKKBaru"
                        checked={formData.buatKKBaru}
                        onChange={(e) => setFormData({ ...formData, buatKKBaru: e.target.checked })}
                        className="rounded"
                      />
                      <Label htmlFor="buatKKBaru">Buat KK Baru (jika tidak ada KK tujuan)</Label>
                    </div>

                    {!formData.buatKKBaru && (
                      <div>
                        <Label>Pilih No KK Tujuan</Label>
                        <Select value={selectedKK} onValueChange={setSelectedKK}>
                          <SelectTrigger>
                            <SelectValue placeholder="Pilih No KK" />
                          </SelectTrigger>
                          <SelectContent>
                            {kkOptions.map((kk) => (
                              <SelectItem key={kk.id} value={kk.id}>
                                {kk.noKK} - {kk.namaKepalaKeluarga}
                              </SelectItem>
                            ))}
                          </SelectContent>
                        </Select>
                      </div>
                    )}

                    {formData.buatKKBaru && (
                      <div className="grid grid-cols-1 md:grid-cols-2 gap-3">
                        <Input placeholder="No KK Baru" value={formData.noKKBaru} onChange={(e) => setFormData({ ...formData, noKKBaru: e.target.value })} required />
                        <Input placeholder="Nama Kepala Keluarga" value={formData.namaKepalaKeluargaBaru} onChange={(e) => setFormData({ ...formData, namaKepalaKeluargaBaru: e.target.value })} required />
                      </div>
                    )}

                    <div className="border-t pt-4">
                      <Label className="font-semibold">Data Penduduk Datang {formData.buatKKBaru ? '(Kepala Keluarga)' : ''}</Label>
                      <div className="grid grid-cols-1 md:grid-cols-2 gap-3 mt-2">
                        <Input placeholder="NIK" value={formData.nikDatang} onChange={(e) => setFormData({ ...formData, nikDatang: e.target.value })} required />
                        <Input placeholder="Nama" value={formData.namaDatang} onChange={(e) => setFormData({ ...formData, namaDatang: e.target.value })} required />
                        <Select value={formData.jenisKelaminDatang} onValueChange={(v) => setFormData({ ...formData, jenisKelaminDatang: v })}>
                          <SelectTrigger><SelectValue /></SelectTrigger>
                          <SelectContent>
                            <SelectItem value="Laki-Laki">Laki-Laki</SelectItem>
                            <SelectItem value="Perempuan">Perempuan</SelectItem>
                          </SelectContent>
                        </Select>
                        <Input placeholder="Tempat Lahir" value={formData.tempatLahirDatang} onChange={(e) => setFormData({ ...formData, tempatLahirDatang: e.target.value })} />
                        <Input type="date" value={formData.tanggalLahirDatang} onChange={(e) => setFormData({ ...formData, tanggalLahirDatang: e.target.value })} />
                      </div>
                    </div>

                    {/* Tambah Anggota Keluarga Datang */}
                    <div className="border-t pt-4">
                      <div className="flex items-center justify-between mb-3">
                        <Label className="font-semibold text-blue-700">Tambah Anggota Keluarga yang Datang</Label>
                        <Button
                          type="button"
                          variant="outline"
                          size="sm"
                          onClick={addAnggotaDatang}
                          className="text-blue-600 border-blue-600"
                        >
                          <UserPlus className="h-4 w-4 mr-1" />
                          Tambah Anggota
                        </Button>
                      </div>
                      
                      {anggotaDatang.length > 0 && (
                        <div className="space-y-3">
                          {anggotaDatang.map((anggota, index) => (
                            <div key={index} className="border rounded-lg p-3 bg-blue-50">
                              <div className="flex items-center justify-between mb-2">
                                <span className="text-sm font-medium text-gray-600">Anggota {index + 1}</span>
                                <Button
                                  type="button"
                                  variant="ghost"
                                  size="sm"
                                  onClick={() => removeAnggotaDatang(index)}
                                >
                                  <X className="h-4 w-4 text-red-500" />
                                </Button>
                              </div>
                              <div className="grid grid-cols-1 md:grid-cols-2 gap-2">
                                <Input
                                  placeholder="NIK"
                                  value={anggota.nik}
                                  onChange={(e) => updateAnggotaDatang(index, 'nik', e.target.value)}
                                />
                                <Input
                                  placeholder="Nama Lengkap"
                                  value={anggota.nama}
                                  onChange={(e) => updateAnggotaDatang(index, 'nama', e.target.value)}
                                />
                                <Select
                                  value={anggota.jenisKelamin}
                                  onValueChange={(v) => updateAnggotaDatang(index, 'jenisKelamin', v)}
                                >
                                  <SelectTrigger>
                                    <SelectValue placeholder="Jenis Kelamin" />
                                  </SelectTrigger>
                                  <SelectContent>
                                    <SelectItem value="Laki-Laki">Laki-Laki</SelectItem>
                                    <SelectItem value="Perempuan">Perempuan</SelectItem>
                                  </SelectContent>
                                </Select>
                                <Input
                                  placeholder="Tempat Lahir"
                                  value={anggota.tempatLahir}
                                  onChange={(e) => updateAnggotaDatang(index, 'tempatLahir', e.target.value)}
                                />
                                <Input
                                  type="date"
                                  value={anggota.tanggalLahir}
                                  onChange={(e) => updateAnggotaDatang(index, 'tanggalLahir', e.target.value)}
                                />
                                <Input
                                  placeholder="Nama Panggilan"
                                  value={anggota.namaPanggilan}
                                  onChange={(e) => updateAnggotaDatang(index, 'namaPanggilan', e.target.value)}
                                />
                                <Input
                                  placeholder="Nama Ayah"
                                  value={anggota.namaAyah}
                                  onChange={(e) => updateAnggotaDatang(index, 'namaAyah', e.target.value)}
                                />
                                <Input
                                  placeholder="Nama Ibu"
                                  value={anggota.namaIbu}
                                  onChange={(e) => updateAnggotaDatang(index, 'namaIbu', e.target.value)}
                                />
                                <Select
                                  value={anggota.bpjs}
                                  onValueChange={(v) => updateAnggotaDatang(index, 'bpjs', v)}
                                >
                                  <SelectTrigger>
                                    <SelectValue placeholder="BPJS" />
                                  </SelectTrigger>
                                  <SelectContent>
                                    <SelectItem value="Tidak">Tidak</SelectItem>
                                    <SelectItem value="Mandiri">Mandiri</SelectItem>
                                    <SelectItem value="PBI">PBI</SelectItem>
                                  </SelectContent>
                                </Select>
                              </div>
                            </div>
                          ))}
                        </div>
                      )}
                    </div>
                  </>
                )}

                {/* Keterangan */}
                <div>
                  <Label htmlFor="keterangan">Keterangan</Label>
                  <Input
                    id="keterangan"
                    value={formData.keterangan}
                    onChange={(e) => setFormData({ ...formData, keterangan: e.target.value })}
                    placeholder="Keterangan tambahan..."
                  />
                </div>
              </div>
            </div>
            <DialogFooter className="mt-4 pt-4 border-t flex-shrink-0">
              <Button type="button" variant="outline" onClick={() => setDialogOpen(false)}>
                Batal
              </Button>
              <Button type="submit" className="bg-emerald-600 hover:bg-emerald-700">
                Simpan
              </Button>
            </DialogFooter>
          </form>
        </DialogContent>
      </Dialog>
    </div>
  )
}
