'use client'

import { useState, useEffect } from 'react'
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card'
import { Badge } from '@/components/ui/badge'
import { Users, Home, UserPlus, FileText, TrendingUp, Clock, IdCard } from 'lucide-react'

interface Penduduk17 {
  id: string
  nik: string
  nama: string
  jenisKelamin: string
  tanggalLahir: string | null
  usia: number
  noKK: string
  namaKK: string
}

interface Statistik {
  kartuKeluarga: { total: number; lakiLaki: number; perempuan: number }
  penduduk: { total: number; lakiLaki: number; perempuan: number }
  umur: {
    bulanan: { '0-11': { l: number; p: number } }
    tahunan: { usia: number; l: number; p: number }[]
  }
  wajibKTP: { 
    lakiLaki: number
    perempuan: number
    total: number
    list: {
      lakiLaki: Penduduk17[]
      perempuan: Penduduk17[]
    }
  }
  wajibKTPBaru: {
    lakiLaki: number
    perempuan: number
    total: number
    list: {
      lakiLaki: Penduduk17[]
      perempuan: Penduduk17[]
    }
  }
  akan17Tahun: {
    lakiLaki: number
    perempuan: number
    total: number
    list: {
      lakiLaki: Penduduk17[]
      perempuan: Penduduk17[]
    }
  }
  penduduk17Tahun: {
    lakiLaki: number
    perempuan: number
    total: number
    list: {
      lakiLaki: Penduduk17[]
      perempuan: Penduduk17[]
    }
  }
  pendudukSementara: { lakiLaki: number; perempuan: number }
  kejadian: {
    lahir: { total: number; l: number; p: number }
    meninggal: { total: number; l: number; p: number }
    pindah: { total: number; l: number; p: number }
    datang: { total: number; l: number; p: number }
  }
}

export function BerandaTab() {
  const [statistik, setStatistik] = useState<Statistik | null>(null)
  const [loading, setLoading] = useState(true)
  const [show17Tahun, setShow17Tahun] = useState(false)

  useEffect(() => {
    fetchStatistik()
  }, [])

  const fetchStatistik = async () => {
    try {
      const res = await fetch('/api/statistik')
      const data = await res.json()
      setStatistik(data)
    } catch (error) {
      console.error('Error fetching statistik:', error)
    } finally {
      setLoading(false)
    }
  }

  const formatDate = (date: string | null) => {
    if (!date) return '-'
    const d = new Date(date)
    return `${d.getDate().toString().padStart(2, '0')}/${(d.getMonth() + 1).toString().padStart(2, '0')}/${d.getFullYear()}`
  }

  if (loading) {
    return (
      <div className="flex items-center justify-center h-64">
        <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-emerald-600"></div>
      </div>
    )
  }

  if (!statistik) {
    return (
      <div className="text-center py-8">
        <p className="text-gray-500">Gagal memuat data statistik</p>
      </div>
    )
  }

  // Gabungkan semua penduduk 17 tahun dari wajibKTP
  const semuaPenduduk17 = [...statistik.wajibKTP.list.lakiLaki, ...statistik.wajibKTP.list.perempuan]
  
  // Gabungkan semua yang akan 17 tahun
  const akan17List = [...statistik.akan17Tahun.list.lakiLaki, ...statistik.akan17Tahun.list.perempuan]

  return (
    <div className="space-y-4">
      {/* Summary Cards */}
      <div className="grid grid-cols-2 lg:grid-cols-4 gap-3">
        <Card className="bg-gradient-to-br from-emerald-500 to-emerald-600 text-white">
          <CardHeader className="pb-2 pt-3 px-4">
            <CardTitle className="text-sm font-medium flex items-center gap-2">
              <Home className="h-4 w-4" />
              Kartu Keluarga
            </CardTitle>
          </CardHeader>
          <CardContent className="pb-3 px-4">
            <div className="text-2xl font-bold">{statistik.kartuKeluarga.total}</div>
            <div className="text-xs text-emerald-100 mt-1">
              L: {statistik.kartuKeluarga.lakiLaki} | P: {statistik.kartuKeluarga.perempuan}
            </div>
          </CardContent>
        </Card>

        <Card className="bg-gradient-to-br from-blue-500 to-blue-600 text-white">
          <CardHeader className="pb-2 pt-3 px-4">
            <CardTitle className="text-sm font-medium flex items-center gap-2">
              <Users className="h-4 w-4" />
              Total Penduduk
            </CardTitle>
          </CardHeader>
          <CardContent className="pb-3 px-4">
            <div className="text-2xl font-bold">{statistik.penduduk.total}</div>
            <div className="text-xs text-blue-100 mt-1">
              L: {statistik.penduduk.lakiLaki} | P: {statistik.penduduk.perempuan}
            </div>
          </CardContent>
        </Card>

        <Card className="bg-gradient-to-br from-purple-500 to-purple-600 text-white">
          <CardHeader className="pb-2 pt-3 px-4">
            <CardTitle className="text-sm font-medium flex items-center gap-2">
              <IdCard className="h-4 w-4" />
              Wajib KTP (17 Thn)
            </CardTitle>
          </CardHeader>
          <CardContent className="pb-3 px-4">
            <div className="text-2xl font-bold">{statistik.wajibKTP.total}</div>
            <div className="text-xs text-purple-100 mt-1">
              L: {statistik.wajibKTP.lakiLaki} | P: {statistik.wajibKTP.perempuan}
            </div>
          </CardContent>
        </Card>

        <Card className="bg-gradient-to-br from-orange-500 to-orange-600 text-white">
          <CardHeader className="pb-2 pt-3 px-4">
            <CardTitle className="text-sm font-medium flex items-center gap-2">
              <TrendingUp className="h-4 w-4" />
              Penduduk Sementara
            </CardTitle>
          </CardHeader>
          <CardContent className="pb-3 px-4">
            <div className="text-2xl font-bold">{statistik.pendudukSementara.lakiLaki + statistik.pendudukSementara.perempuan}</div>
            <div className="text-xs text-orange-100 mt-1">
              L: {statistik.pendudukSementara.lakiLaki} | P: {statistik.pendudukSementara.perempuan}
            </div>
          </CardContent>
        </Card>
      </div>

      {/* Yang akan 17 tahun dalam 30 hari */}
      {statistik.akan17Tahun.total > 0 && (
        <Card className="border-2 border-yellow-200 bg-yellow-50/50">
          <CardHeader className="py-3 px-4 bg-yellow-100 rounded-t-lg">
            <CardTitle className="text-base flex items-center gap-2 text-yellow-800">
              <Clock className="h-5 w-5" />
              Akan Berusia 17 Tahun (30 hari ke depan)
              <Badge variant="secondary" className="ml-auto bg-yellow-200 text-yellow-800">
                {statistik.akan17Tahun.total} orang
              </Badge>
            </CardTitle>
          </CardHeader>
          <CardContent className="px-4 pb-4 pt-3">
            <div className="overflow-x-auto">
              <table className="w-full text-sm">
                <thead>
                  <tr className="border-b border-yellow-200">
                    <th className="text-left py-2 px-2">No</th>
                    <th className="text-left py-2 px-2">NIK</th>
                    <th className="text-left py-2 px-2">Nama</th>
                    <th className="text-left py-2 px-2">JK</th>
                    <th className="text-left py-2 px-2">TTL</th>
                    <th className="text-left py-2 px-2">No KK</th>
                  </tr>
                </thead>
                <tbody>
                  {akan17List.map((p, index) => (
                    <tr key={p.id} className="border-b border-yellow-100 hover:bg-yellow-50">
                      <td className="py-2 px-2">{index + 1}</td>
                      <td className="py-2 px-2 font-mono text-xs">{p.nik}</td>
                      <td className="py-2 px-2 font-medium">{p.nama}</td>
                      <td className="py-2 px-2">
                        <Badge variant={p.jenisKelamin === 'Laki-Laki' ? 'default' : 'secondary'} className="text-xs">
                          {p.jenisKelamin === 'Laki-Laki' ? 'L' : 'P'}
                        </Badge>
                      </td>
                      <td className="py-2 px-2 text-xs">{formatDate(p.tanggalLahir)}</td>
                      <td className="py-2 px-2 font-mono text-xs">{p.noKK}</td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          </CardContent>
        </Card>
      )}

      {/* Penduduk 17 Tahun (Wajib KTP) */}
      <Card className="border-2 border-purple-200 bg-purple-50/50">
        <CardHeader className="py-3 px-4 bg-purple-100 rounded-t-lg">
          <CardTitle className="text-base flex items-center gap-2 text-purple-800">
            <IdCard className="h-5 w-5" />
            Penduduk Usia 17 Tahun (Wajib KTP)
            <Badge variant="secondary" className="ml-auto bg-purple-200 text-purple-800">
              {statistik.wajibKTP.total} orang
            </Badge>
          </CardTitle>
          <p className="text-xs text-purple-600 mt-1">
            L: {statistik.wajibKTP.lakiLaki} | P: {statistik.wajibKTP.perempuan}
          </p>
        </CardHeader>
        <CardContent className="px-4 pb-4 pt-3">
          {semuaPenduduk17.length === 0 ? (
            <p className="text-gray-500 text-center py-4">Tidak ada penduduk berusia 17 tahun</p>
          ) : (
            <div className="overflow-x-auto">
              <table className="w-full text-sm">
                <thead>
                  <tr className="border-b border-purple-200">
                    <th className="text-left py-2 px-2">No</th>
                    <th className="text-left py-2 px-2">NIK</th>
                    <th className="text-left py-2 px-2">Nama</th>
                    <th className="text-left py-2 px-2">JK</th>
                    <th className="text-left py-2 px-2">TTL</th>
                    <th className="text-left py-2 px-2">No KK</th>
                  </tr>
                </thead>
                <tbody>
                  {semuaPenduduk17.map((p, index) => (
                    <tr key={p.id} className="border-b border-purple-100 hover:bg-purple-50">
                      <td className="py-2 px-2">{index + 1}</td>
                      <td className="py-2 px-2 font-mono text-xs">{p.nik}</td>
                      <td className="py-2 px-2 font-medium">{p.nama}</td>
                      <td className="py-2 px-2">
                        <Badge variant={p.jenisKelamin === 'Laki-Laki' ? 'default' : 'secondary'} className="text-xs">
                          {p.jenisKelamin === 'Laki-Laki' ? 'L' : 'P'}
                        </Badge>
                      </td>
                      <td className="py-2 px-2 text-xs">{formatDate(p.tanggalLahir)}</td>
                      <td className="py-2 px-2 font-mono text-xs">{p.noKK}</td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          )}
        </CardContent>
      </Card>

      {/* Wajib KTP Baru (dalam 30 hari terakhir) */}
      {statistik.wajibKTPBaru.total > 0 && (
        <Card className="border-2 border-green-200 bg-green-50/50">
          <CardHeader className="py-3 px-4 bg-green-100 rounded-t-lg">
            <CardTitle className="text-base flex items-center gap-2 text-green-800">
              <UserPlus className="h-5 w-5" />
              Baru 17 Tahun (30 hari terakhir)
              <Badge variant="secondary" className="ml-auto bg-green-200 text-green-800">
                {statistik.wajibKTPBaru.total} orang
              </Badge>
            </CardTitle>
          </CardHeader>
          <CardContent className="px-4 pb-4 pt-3">
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              {statistik.wajibKTPBaru.list.lakiLaki.length > 0 && (
                <div>
                  <p className="text-sm font-medium text-gray-700 mb-2">Laki-Laki ({statistik.wajibKTPBaru.list.lakiLaki.length})</p>
                  {statistik.wajibKTPBaru.list.lakiLaki.map((p) => (
                    <div key={p.id} className="flex items-center gap-2 py-1 border-b border-green-100">
                      <Badge variant="default" className="text-xs">L</Badge>
                      <span className="font-medium">{p.nama}</span>
                      <span className="text-xs text-gray-500 font-mono">{p.nik}</span>
                    </div>
                  ))}
                </div>
              )}
              {statistik.wajibKTPBaru.list.perempuan.length > 0 && (
                <div>
                  <p className="text-sm font-medium text-gray-700 mb-2">Perempuan ({statistik.wajibKTPBaru.list.perempuan.length})</p>
                  {statistik.wajibKTPBaru.list.perempuan.map((p) => (
                    <div key={p.id} className="flex items-center gap-2 py-1 border-b border-green-100">
                      <Badge variant="secondary" className="text-xs">P</Badge>
                      <span className="font-medium">{p.nama}</span>
                      <span className="text-xs text-gray-500 font-mono">{p.nik}</span>
                    </div>
                  ))}
                </div>
              )}
            </div>
          </CardContent>
        </Card>
      )}

      {/* Age Tables */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-4">
        {/* Umur Bulanan */}
        <Card>
          <CardHeader className="py-3 px-4">
            <CardTitle className="text-base">Umur 0-11 Bulan</CardTitle>
          </CardHeader>
          <CardContent className="px-4 pb-4">
            <table className="w-full text-sm">
              <thead>
                <tr className="border-b">
                  <th className="text-left py-2">Usia</th>
                  <th className="text-center py-2">Laki-Laki</th>
                  <th className="text-center py-2">Perempuan</th>
                </tr>
              </thead>
              <tbody>
                <tr className="border-b">
                  <td className="py-2">0-11 Bulan</td>
                  <td className="text-center py-2">{statistik.umur.bulanan['0-11'].l}</td>
                  <td className="text-center py-2">{statistik.umur.bulanan['0-11'].p}</td>
                </tr>
              </tbody>
            </table>
          </CardContent>
        </Card>

        {/* Kejadian Summary */}
        <Card>
          <CardHeader className="py-3 px-4">
            <CardTitle className="text-base flex items-center gap-2">
              <FileText className="h-4 w-4" />
              Data Kejadian
            </CardTitle>
          </CardHeader>
          <CardContent className="px-4 pb-4">
            <table className="w-full text-sm">
              <thead>
                <tr className="border-b">
                  <th className="text-left py-2">Kejadian</th>
                  <th className="text-center py-2">Laki-Laki</th>
                  <th className="text-center py-2">Perempuan</th>
                  <th className="text-center py-2">Total</th>
                </tr>
              </thead>
              <tbody>
                <tr className="border-b">
                  <td className="py-2">Lahir</td>
                  <td className="text-center py-2">{statistik.kejadian.lahir.l}</td>
                  <td className="text-center py-2">{statistik.kejadian.lahir.p}</td>
                  <td className="text-center py-2">{statistik.kejadian.lahir.total}</td>
                </tr>
                <tr className="border-b">
                  <td className="py-2">Meninggal</td>
                  <td className="text-center py-2">{statistik.kejadian.meninggal.l}</td>
                  <td className="text-center py-2">{statistik.kejadian.meninggal.p}</td>
                  <td className="text-center py-2">{statistik.kejadian.meninggal.total}</td>
                </tr>
                <tr className="border-b">
                  <td className="py-2">Pindah</td>
                  <td className="text-center py-2">{statistik.kejadian.pindah.l}</td>
                  <td className="text-center py-2">{statistik.kejadian.pindah.p}</td>
                  <td className="text-center py-2">{statistik.kejadian.pindah.total}</td>
                </tr>
                <tr>
                  <td className="py-2">Datang</td>
                  <td className="text-center py-2">{statistik.kejadian.datang.l}</td>
                  <td className="text-center py-2">{statistik.kejadian.datang.p}</td>
                  <td className="text-center py-2">{statistik.kejadian.datang.total}</td>
                </tr>
              </tbody>
            </table>
          </CardContent>
        </Card>
      </div>

      {/* Umur Per Tahun */}
      <Card>
        <CardHeader className="py-3 px-4">
          <CardTitle className="text-base">Umur Per Tahun</CardTitle>
        </CardHeader>
        <CardContent className="px-4 pb-4">
          <div className="max-h-64 overflow-y-auto">
            <table className="w-full text-sm">
              <thead className="sticky top-0 bg-white">
                <tr className="border-b">
                  <th className="text-left py-2">Usia</th>
                  <th className="text-center py-2">Laki-Laki</th>
                  <th className="text-center py-2">Perempuan</th>
                  <th className="text-center py-2">Total</th>
                </tr>
              </thead>
              <tbody>
                {statistik.umur.tahunan.length === 0 ? (
                  <tr>
                    <td colSpan={4} className="text-center py-4 text-gray-500">
                      Tidak ada data
                    </td>
                  </tr>
                ) : (
                  statistik.umur.tahunan.map((item) => (
                    <tr key={item.usia} className={`border-b ${item.usia === 17 ? 'bg-purple-50 font-medium' : ''}`}>
                      <td className="py-2">
                        {item.usia} Tahun
                        {item.usia === 17 && <Badge className="ml-2 bg-purple-500 text-xs">Wajib KTP</Badge>}
                      </td>
                      <td className="text-center py-2">{item.l}</td>
                      <td className="text-center py-2">{item.p}</td>
                      <td className="text-center py-2">{item.l + item.p}</td>
                    </tr>
                  ))
                )}
              </tbody>
            </table>
          </div>
        </CardContent>
      </Card>
    </div>
  )
}
